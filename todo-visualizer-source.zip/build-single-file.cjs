const fs = require('fs');
const path = require('path');

const distDir = path.join(__dirname, 'dist');
const html = fs.readFileSync(path.join(distDir, 'index.html'), 'utf-8');
const assetsDir = path.join(distDir, 'assets');

// Find JS and CSS files
const files = fs.readdirSync(assetsDir);
const jsFile = files.find(f => f.endsWith('.js'));
const cssFile = files.find(f => f.endsWith('.css'));

const js = fs.readFileSync(path.join(assetsDir, jsFile), 'utf-8');
const css = fs.readFileSync(path.join(assetsDir, cssFile), 'utf-8');

// Replace references with inline content
let result = html
  .replace(/<script type="module" crossorigin src="[^"]+"><\/script>/, `<script type="module">${js}</script>`)
  .replace(/<link rel="stylesheet" crossorigin href="[^"]+">/, `<style>${css}</style>`)
  .replace('href="/favicon.svg"', 'href="data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 32 32%22%3E%3Crect width=%2232%22 height=%2232%22 rx=%228%22 fill=%22%236366f1%22/%3E%3Crect x=%226%22 y=%2210%22 width=%225%22 height=%2214%22 rx=%221%22 fill=%22white%22/%3E%3Crect x=%2213.5%22 y=%227%22 width=%225%22 height=%2217%22 rx=%221%22 fill=%22white%22/%3E%3Crect x=%2221%22 y=%2212%22 width=%225%22 height=%2212%22 rx=%221%22 fill=%22white%22/%3E%3C/svg%3E"');

const title = 'Todo可视化';
result = result.replace('Work Capacity Editor', title);

const outPath = path.join(__dirname, 'Todo可视化.html');
fs.writeFileSync(outPath, result);
console.log(`Built: ${outPath} (${(result.length / 1024).toFixed(1)} KB)`);
