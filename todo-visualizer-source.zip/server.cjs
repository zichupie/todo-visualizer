/**
 * Todo Visualizer - Standalone Server
 * 用于 pkg 打包为单文件 .exe 或直接 node server.cjs 运行
 */
const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = 5000;
const DIST = path.join(__dirname, 'dist');

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.webp': 'image/webp',
};

const server = http.createServer((req, res) => {
  const reqPath = req.url === '/' ? '/index.html' : req.url.split('?')[0];
  const filePath = path.join(DIST, reqPath);

  if (!filePath.startsWith(DIST)) {
    res.writeHead(403);
    return res.end('Forbidden');
  }

  const ext = path.extname(filePath);
  const contentType = MIME[ext] || 'application/octet-stream';

  try {
    const data = fs.readFileSync(filePath);
    res.writeHead(200, { 'Content-Type': contentType, 'Cache-Control': 'no-cache' });
    res.end(data);
  } catch (_err) {
    // SPA fallback
    try {
      const fallback = fs.readFileSync(path.join(DIST, 'index.html'));
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      res.end(fallback);
    } catch {
      res.writeHead(404);
      res.end('Not Found');
    }
  }
});

server.listen(PORT, () => {
  process.stdout.write(`\n  Todo Visualizer: http://localhost:${PORT}\n  Press Ctrl+C to stop.\n\n`);
  // Try open browser (best-effort, ignore errors)
  try {
    const { exec } = require('child_process');
    const cmd = process.platform === 'win32'
      ? `start http://localhost:${PORT}`
      : process.platform === 'darwin'
        ? `open http://localhost:${PORT}`
        : `xdg-open http://localhost:${PORT}`;
    exec(cmd, () => {});
  } catch { /* ignore */ }
});
