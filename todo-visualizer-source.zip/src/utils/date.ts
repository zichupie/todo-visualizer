/**
 * 获取本周的日期范围（周一到周日）
 */
export function getWeekRange(date: Date = new Date()): { start: Date; end: Date } {
  const day = date.getDay();
  const diff = day === 0 ? -6 : 1 - day; // 周一为起始

  const monday = new Date(date);
  monday.setDate(date.getDate() + diff);
  monday.setHours(0, 0, 0, 0);

  const sunday = new Date(monday);
  sunday.setDate(monday.getDate() + 6);
  sunday.setHours(23, 59, 59, 999);

  return { start: monday, end: sunday };
}

/**
 * 获取本周所有日期的字符串数组
 */
export function getWeekDates(date: Date = new Date()): string[] {
  const { start } = getWeekRange(date);
  const dates: string[] = [];

  for (let i = 0; i < 7; i++) {
    const d = new Date(start);
    d.setDate(start.getDate() + i);
    dates.push(formatDate(d));
  }

  return dates;
}

/**
 * 格式化日期为 YYYY-MM-DD
 */
export function formatDate(date: Date): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

/**
 * 格式化日期为显示格式（月日+周几）
 */
export function formatDateDisplay(dateStr: string): { date: string; weekday: string } {
  const date = new Date(dateStr + 'T00:00:00');
  const weekdays = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];

  return {
    date: `${date.getMonth() + 1}/${date.getDate()}`,
    weekday: weekdays[date.getDay()],
  };
}

/**
 * 判断是否是今天
 */
export function isToday(dateStr: string): boolean {
  return dateStr === formatDate(new Date());
}
