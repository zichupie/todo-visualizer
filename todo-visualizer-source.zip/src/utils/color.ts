import { PRESET_COLORS } from '@/types';

/**
 * 从预设颜色池中获取一个未使用的颜色
 */
export function getUnusedColor(usedColors: Set<string>): string {
  return PRESET_COLORS.find((c) => !usedColors.has(c)) || PRESET_COLORS[0];
}

/**
 * 判断颜色是否为浅色
 */
export function isLightColor(hex: string): boolean {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  return luminance > 0.6;
}

/**
 * Hex 转 RGBA
 */
export function hexToRgba(hex: string, alpha: number): string {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}
