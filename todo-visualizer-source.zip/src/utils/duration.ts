/**
 * 格式化分钟数为可读字符串
 */
export function formatDuration(minutes: number): string {
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;

  if (hours === 0 && mins === 0) return '0 分钟';
  if (hours === 0) return `${mins} 分钟`;
  if (mins === 0) return `${hours} 小时`;

  return `${hours} 小时 ${mins} 分钟`;
}

/**
 * 格式化分钟数为简写
 */
export function formatDurationShort(minutes: number): string {
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;

  if (hours === 0) return `${mins}min`;
  if (mins === 0) return `${hours}h`;

  return `${hours}h ${mins}min`;
}

/**
 * 将时间字符串 (HH:MM) 转换为分钟数
 */
export function timeToMinutes(time: string): number {
  const [h, m] = time.split(':').map(Number);
  return h * 60 + m;
}

/**
 * 将分钟数转换为时间字符串 (HH:MM)
 */
export function minutesToTime(minutes: number): string {
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

/**
 * 计算给定分钟数对应的像素高度
 */
export function durationToPx(minutes: number, pxPerHour: number): number {
  return (minutes / 60) * pxPerHour;
}

/**
 * 计算给定像素高度对应的分钟数（按小时取整）
 */
export function pxToDuration(px: number, pxPerHour: number): number {
  const hours = px / pxPerHour;
  return Math.round(hours) * 60; // 最小粒度 1 小时
}

/**
 * 计算使用百分比
 */
export function calculateUsagePercent(used: number, capacity: number): number {
  if (capacity <= 0) return 0;
  return Math.min(100, Math.round((used / capacity) * 100));
}

/**
 * 获取使用率颜色类名
 */
export function getUsageColor(percent: number): string {
  if (percent > 100) return 'text-danger';
  if (percent > 80) return 'text-warning';
  if (percent > 60) return 'text-accent';
  return 'text-text-secondary';
}
