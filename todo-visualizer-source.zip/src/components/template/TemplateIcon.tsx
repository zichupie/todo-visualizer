import {
  ClipboardList, StickyNote, Pencil, Wrench, BookOpen, Briefcase, Coffee,
  Code, Database, FileText, Globe, Heart, Home, Image, Mail, MessageSquare,
  Music, Phone, Search, Settings, ShoppingCart, Star, Truck, User, Video, Zap,
  HelpCircle,
} from 'lucide-react';

// 图标名称 → Lucide 组件映射
const iconMap: Record<string, React.ComponentType<{ size?: number; className?: string }>> = {
  'clipboard-list': ClipboardList,
  'sticky-note': StickyNote,
  'pencil': Pencil,
  'wrench': Wrench,
  'book-open': BookOpen,
  'briefcase': Briefcase,
  'coffee': Coffee,
  'code': Code,
  'database': Database,
  'file-text': FileText,
  'globe': Globe,
  'heart': Heart,
  'home': Home,
  'image': Image,
  'mail': Mail,
  'message-square': MessageSquare,
  'music': Music,
  'phone': Phone,
  'search': Search,
  'settings': Settings,
  'shopping-cart': ShoppingCart,
  'star': Star,
  'truck': Truck,
  'user': User,
  'video': Video,
  'zap': Zap,
};

interface TemplateIconProps {
  name: string;
  size?: number;
  className?: string;
}

export function TemplateIcon({ name, size = 16, className }: TemplateIconProps) {
  const Icon = iconMap[name] || HelpCircle;
  return <Icon size={size} className={className} />;
}

export { iconMap };
