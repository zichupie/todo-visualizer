import { useState, useEffect } from 'react';
import { CheckCircle2 } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Modal } from '@/components/ui/Modal';
import { TemplateIcon } from './TemplateIcon';
import { iconMap } from './TemplateIcon';
import { useTemplateStore } from '@/stores/useTemplateStore';
import { useSettingStore } from '@/stores/useSettingStore';
import { PRESET_COLORS, STATUS_LABELS } from '@/types';
import type { Template, TaskStatus } from '@/types';
import { formatDurationShort } from '@/utils/duration';

interface TemplateFormModalProps {
  open: boolean;
  onClose: () => void;
  editingTemplate?: Template | null;
}

export function TemplateFormModal({ open, onClose, editingTemplate }: TemplateFormModalProps) {
  const { addTemplate, updateTemplate, categories, selectedCategoryId } = useTemplateStore();
  const { settings } = useSettingStore();
  const isEditing = !!editingTemplate;

  const [name, setName] = useState('');
  const [iconValue, setIconValue] = useState('clipboard-list');
  const [color, setColor] = useState(PRESET_COLORS[0]);
  const [durationHours, setDurationHours] = useState(1);
  const [categoryId, setCategoryId] = useState<string | null>(null);
  const [status, setStatus] = useState<TaskStatus>('todo');
  const [errors, setErrors] = useState<Record<string, string>>({});

  // 打开/切换时初始化表单
  useEffect(() => {
    if (!open) return;

    if (editingTemplate) {
      setName(editingTemplate.name);
      setIconValue(editingTemplate.iconValue);
      setColor(editingTemplate.color);
      setDurationHours(Math.floor(editingTemplate.defaultDuration / 60));
      setCategoryId(editingTemplate.categoryId);
      setStatus(editingTemplate.defaultStatus);
    } else {
      setName('');
      setIconValue('clipboard-list');
      setColor(PRESET_COLORS[0]);
      setDurationHours(1);
      setCategoryId(selectedCategoryId);
      setStatus('todo');
    }
    setErrors({});
  }, [open, editingTemplate, selectedCategoryId]);

  const validate = (): boolean => {
    const errs: Record<string, string> = {};
    if (!name.trim()) errs.name = '请输入模板名称';
    if (durationHours < 0.5 || durationHours > 24) errs.duration = '时长需在 0.5~24 小时之间';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = () => {
    if (!validate()) return;

    const data = {
      name: name.trim(),
      iconType: 'lucide' as const,
      iconValue,
      color,
      defaultDuration: durationHours * 60,
      categoryId,
      defaultStatus: status,
    };

    if (isEditing) {
      updateTemplate(editingTemplate!.id, data);
    } else {
      addTemplate(data);
    }

    onClose();
  };

  const iconKeys = Object.keys(iconMap);

  return (
    <Modal open={open} onClose={onClose} title={isEditing ? '编辑模板' : '新建模板'} width="lg">
      <div className="flex flex-col gap-5">
        {/* 名称 */}
        <div>
          <label className="mb-1.5 block text-xs font-medium" style={{ color: 'var(--color-text-secondary)' }}>
            模板名称
          </label>
          <input
            type="text"
            value={name}
            onChange={(e) => {
              setName(e.target.value);
              if (errors.name) setErrors((prev) => { const n = { ...prev }; delete n.name; return n; });
            }}
            placeholder="例如：项目开发、会议、学习"
            className="w-full rounded-lg border px-3 py-2 text-sm outline-none transition-colors duration-150 focus:border-[var(--color-accent)]"
            style={{
              background: 'var(--color-surface)',
              borderColor: errors.name ? 'var(--color-danger)' : 'var(--color-border)',
              color: 'var(--color-text-primary)',
            }}
            autoFocus
          />
          {errors.name && (
            <p className="mt-1 text-[11px]" style={{ color: 'var(--color-danger)' }}>{errors.name}</p>
          )}
        </div>

        {/* 图标选择 */}
        <div>
          <label className="mb-1.5 block text-xs font-medium" style={{ color: 'var(--color-text-secondary)' }}>
            图标
          </label>
          <div className="grid grid-cols-9 gap-1.5">
            {iconKeys.map((iconName) => (
              <button
                key={iconName}
                type="button"
                onClick={() => setIconValue(iconName)}
                className="flex items-center justify-center rounded-lg p-2 transition-all duration-150"
                style={{
                  background: iconValue === iconName ? color + '18' : 'var(--color-surface-secondary)',
                  border: iconValue === iconName ? `2px solid ${color}` : '2px solid transparent',
                  color: iconValue === iconName ? color : 'var(--color-text-muted)',
                }}
              >
                <TemplateIcon name={iconName} size={16} />
              </button>
            ))}
          </div>
        </div>

        {/* 颜色选择 */}
        <div>
          <label className="mb-1.5 block text-xs font-medium" style={{ color: 'var(--color-text-secondary)' }}>
            颜色
          </label>
          <div className="flex flex-wrap gap-2">
            {PRESET_COLORS.map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => setColor(c)}
                className="relative h-7 w-7 rounded-full transition-all duration-150 flex items-center justify-center"
                style={{
                  background: c,
                  transform: color === c ? 'scale(1.2)' : 'scale(1)',
                  boxShadow: color === c ? `0 0 0 2px var(--color-surface), 0 0 0 4px ${c}` : 'none',
                }}
              >
                {color === c && <CheckCircle2 size={12} style={{ color: '#fff' }} />}
              </button>
            ))}
          </div>
        </div>

        {/* 时长 + 分类 + 状态 */}
        <div className="grid grid-cols-3 gap-4">
          {/* 时长 */}
          <div>
            <label className="mb-1.5 block text-xs font-medium" style={{ color: 'var(--color-text-secondary)' }}>
              默认时长
            </label>
            <input
              type="number"
              min={0.5}
              max={24}
              step={0.5}
              value={durationHours}
              onChange={(e) => setDurationHours(parseFloat(e.target.value) || 1)}
              className="w-full rounded-lg border px-3 py-2 text-sm text-center outline-none transition-colors duration-150 focus:border-[var(--color-accent)]"
              style={{
                background: 'var(--color-surface)',
                borderColor: errors.duration ? 'var(--color-danger)' : 'var(--color-border)',
                color: 'var(--color-text-primary)',
              }}
            />
            <p className="mt-1 text-[10px] text-center" style={{ color: 'var(--color-text-muted)' }}>
              {formatDurationShort(durationHours * 60)}
            </p>
          </div>

          {/* 分类 */}
          <div>
            <label className="mb-1.5 block text-xs font-medium" style={{ color: 'var(--color-text-secondary)' }}>
              分类
            </label>
            <select
              value={categoryId || ''}
              onChange={(e) => setCategoryId(e.target.value || null)}
              className="w-full rounded-lg border px-2 py-2 text-sm outline-none transition-colors duration-150 focus:border-[var(--color-accent)]"
              style={{
                background: 'var(--color-surface)',
                borderColor: 'var(--color-border)',
                color: 'var(--color-text-primary)',
              }}
            >
              <option value="">未分类</option>
              {categories.map((cat) => (
                <option key={cat.id} value={cat.id}>{cat.name}</option>
              ))}
            </select>
          </div>

          {/* 默认状态 */}
          <div>
            <label className="mb-1.5 block text-xs font-medium" style={{ color: 'var(--color-text-secondary)' }}>
              默认状态
            </label>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value as TaskStatus)}
              className="w-full rounded-lg border px-2 py-2 text-sm outline-none transition-colors duration-150 focus:border-[var(--color-accent)]"
              style={{
                background: 'var(--color-surface)',
                borderColor: 'var(--color-border)',
                color: 'var(--color-text-primary)',
              }}
            >
              {(Object.entries(STATUS_LABELS) as [TaskStatus, string][]).map(([key, label]) => (
                <option key={key} value={key}>{label}</option>
              ))}
            </select>
          </div>
        </div>

        {/* 预览 */}
        <div
          className="flex items-center gap-3 rounded-xl border p-3"
          style={{
            background: 'var(--color-surface-secondary)',
            borderColor: 'var(--color-border-subtle)',
          }}
        >
          <span className="shrink-0 text-[10px] font-medium" style={{ color: 'var(--color-text-muted)' }}>预览</span>
          <div
            className="flex items-center gap-2 rounded-lg px-3 py-1.5"
            style={{ background: color + '14', borderLeft: `3px solid ${color}` }}
          >
            <TemplateIcon name={iconValue} size={14} />
            <span className="text-xs font-medium" style={{ color: 'var(--color-text-primary)' }}>
              {name || '未命名模板'}
            </span>
          </div>
        </div>

        {/* Actions */}
        <div className="flex justify-end gap-2 pt-1">
          <Button variant="secondary" size="sm" onClick={onClose}>
            取消
          </Button>
          <Button size="sm" onClick={handleSubmit}>
            {isEditing ? '保存修改' : '创建模板'}
          </Button>
        </div>
      </div>
    </Modal>
  );
}
