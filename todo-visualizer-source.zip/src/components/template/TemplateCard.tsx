import { useState } from 'react';
import { Pencil, Trash2, GripVertical } from 'lucide-react';
import { Badge } from '@/components/ui/Badge';
import { TiltWrapper } from '@/components/effects/TiltWrapper';
import { useTemplateStore } from '@/stores/useTemplateStore';
import { formatDurationShort } from '@/utils/duration';
import { STATUS_LABELS } from '@/types';
import { TemplateIcon } from './TemplateIcon';
import type { Template } from '@/types';

interface TemplateCardProps {
  template: Template;
  onEdit: (template: Template) => void;
}

export function TemplateCard({ template, onEdit }: TemplateCardProps) {
  const { deleteTemplate } = useTemplateStore();
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  const handleDelete = () => {
    if (showDeleteConfirm) {
      deleteTemplate(template.id);
      setShowDeleteConfirm(false);
    } else {
      setShowDeleteConfirm(true);
      setTimeout(() => setShowDeleteConfirm(false), 3000);
    }
  };

  return (
    <TiltWrapper
      rotateAmplitude={10}
      scaleOnHover={1.04}
      className="w-full"
    >
      <div
        className="group relative overflow-hidden rounded-xl border transition-all duration-200 hover:shadow-md"
        style={{
          background: 'var(--color-surface)',
          borderColor: 'var(--color-border)',
        }}
        onMouseLeave={() => setShowDeleteConfirm(false)}
      >
      {/* 颜色条 */}
      <div className="h-1 w-full" style={{ background: template.color }} />

      <div className="p-3.5">
        {/* 头部：图标 + 名称 + 操作 */}
        <div className="mb-2.5 flex items-start justify-between">
          <div className="flex items-center gap-2 min-w-0">
            <GripVertical size={14} className="shrink-0 opacity-20 group-hover:opacity-50 transition-opacity" style={{ color: 'var(--color-text-muted)' }} />
            <div
              className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg"
              style={{ background: template.color + '18', color: template.color }}
            >
              <TemplateIcon name={template.iconValue} size={14} />
            </div>
            <span
              className="truncate text-sm font-medium"
              style={{ color: 'var(--color-text-primary)' }}
              title={template.name}
            >
              {template.name}
            </span>
          </div>
          <div className="flex shrink-0 items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity duration-150">
            <button
              onClick={() => onEdit(template)}
              className="rounded-md p-1 hover:bg-[var(--color-surface-secondary)] transition-colors"
              title="编辑"
            >
              <Pencil size={13} style={{ color: 'var(--color-text-muted)' }} />
            </button>
            <button
              onClick={handleDelete}
              className="rounded-md p-1 transition-colors"
              style={{
                background: showDeleteConfirm ? 'var(--color-danger-muted)' : 'transparent',
              }}
              title={showDeleteConfirm ? '确认删除' : '删除'}
            >
              <Trash2
                size={13}
                style={{ color: showDeleteConfirm ? 'var(--color-danger)' : 'var(--color-text-muted)' }}
              />
            </button>
          </div>
        </div>

        {/* 底部信息 */}
        <div className="flex items-center gap-2">
          <Badge variant="accent" size="sm">{formatDurationShort(template.defaultDuration)}</Badge>
          <Badge size="sm">{STATUS_LABELS[template.defaultStatus]}</Badge>
        </div>
      </div>
    </div>
    </TiltWrapper>
  );
}
