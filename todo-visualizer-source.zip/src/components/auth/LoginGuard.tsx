import { useAuthStore } from '@/stores/useAuthStore';
import { Lock } from 'lucide-react';

/**
 * 只读横幅 - 未登录用户在各编辑入口看到此提示
 */
export function ReadOnlyBanner() {
  const { user, setShowAuthModal } = useAuthStore();

  if (user) return null;

  return (
    <div
      className="flex items-center justify-center gap-2 px-3 py-1.5 text-xs"
      style={{
        background: 'rgba(139,92,246,0.08)',
        borderBottom: '1px solid rgba(139,92,246,0.15)',
      }}
    >
      <Lock size={11} style={{ color: 'var(--color-accent)' }} />
      <span style={{ color: 'var(--color-text-muted)' }}>
        当前为只读模式
      </span>
      <button
        onClick={() => setShowAuthModal(true)}
        className="ml-1 font-medium underline underline-offset-2 transition-colors hover:opacity-80"
        style={{ color: 'var(--color-accent)' }}
      >
        登录后编辑
      </button>
    </div>
  );
}

/**
 * 检查是否允许编辑操作
 * @returns true 表示允许编辑（已登录或未配置 Supabase）
 */
export function useCanEdit(): boolean {
  const { user, configured } = useAuthStore();
  // 未配置 Supabase 时允许编辑（本地模式）
  if (!configured) return true;
  return Boolean(user);
}
