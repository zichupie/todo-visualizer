import { useState } from 'react';
import { useAuthStore } from '@/stores/useAuthStore';
import { Lock, Mail, Eye, EyeOff, Loader2, Shield } from 'lucide-react';

export function AuthModal() {
  const { showAuthModal, setShowAuthModal, signIn, signUp, configured } = useAuthStore();

  const [isRegister, setIsRegister] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  if (!showAuthModal) return null;

  // 未配置 Supabase 时显示配置提示
  if (!configured) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center">
        <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setShowAuthModal(false)} />
        <div
          className="relative z-10 w-full max-w-sm rounded-2xl p-6 shadow-2xl"
          style={{ background: 'var(--color-surface)', border: '1px solid var(--color-border)' }}
        >
          <div className="mb-4 flex items-center gap-2">
            <Shield size={20} style={{ color: 'var(--color-accent)' }} />
            <h2 className="text-base font-semibold" style={{ color: 'var(--color-text-primary)' }}>
              尚未配置后端
            </h2>
          </div>
          <p className="mb-4 text-xs leading-relaxed" style={{ color: 'var(--color-text-muted)' }}>
            需要创建 Supabase 项目并配置环境变量：
          </p>
          <div className="mb-4 rounded-lg p-3 font-mono text-[10px] leading-relaxed" style={{ background: 'var(--color-surface-secondary)' }}>
            <code style={{ color: 'var(--color-accent)' }}>
              VITE_SUPABASE_URL=https://xxx.supabase.co<br />
              VITE_SUPABASE_ANON_KEY=eyJhbG...
            </code>
          </div>
          <button
            onClick={() => setShowAuthModal(false)}
            className="w-full rounded-lg py-2 text-xs font-medium transition-colors"
            style={{ background: 'var(--color-surface-secondary)', color: 'var(--color-text-muted)' }}
          >
            知道了
          </button>
        </div>
      </div>
    );
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!email.trim() || !password.trim()) {
      setError('请填写邮箱和密码');
      return;
    }

    setLoading(true);
    const fn = isRegister ? signUp : signIn;
    const result = await fn(email.trim(), password);
    setLoading(false);

    if (result.error) {
      setError(result.error);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* 遮罩 */}
      <div
        className="absolute inset-0 bg-black/50 backdrop-blur-sm transition-opacity"
        onClick={() => setShowAuthModal(false)}
      />

      {/* 卡片 */}
      <div
        className="relative z-10 w-full max-w-sm overflow-hidden rounded-2xl shadow-2xl"
        style={{ background: 'var(--color-surface)' }}
      >
        {/* 顶部装饰条 */}
        <div
          className="h-1"
          style={{ background: 'linear-gradient(90deg, var(--color-accent), #a78bfa, #f472b6)' }}
        />

        <div className="p-6">
          {/* 图标和标题 */}
          <div className="mb-5 text-center">
            <div
              className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-xl"
              style={{ background: 'var(--color-accent-light, rgba(139,92,246,0.12))' }}
            >
              <Lock size={22} style={{ color: 'var(--color-accent)' }} />
            </div>
            <h2 className="text-lg font-semibold" style={{ color: 'var(--color-text-primary)' }}>
              {isRegister ? '注册管理员' : '管理员登录'}
            </h2>
            <p className="mt-1 text-xs" style={{ color: 'var(--color-text-muted)' }}>
              {isRegister ? '创建管理员账号' : '登录后可编辑数据'}
            </p>
          </div>

          {/* 表单 */}
          <form onSubmit={handleSubmit} className="space-y-3">
            {/* 邮箱 */}
            <div>
              <label
                className="mb-1 block text-xs font-medium"
                style={{ color: 'var(--color-text-secondary)' }}
              >
                邮箱
              </label>
              <div className="relative">
                <Mail
                  size={14}
                  className="absolute left-3 top-1/2 -translate-y-1/2"
                  style={{ color: 'var(--color-text-muted)' }}
                />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="admin@example.com"
                  autoComplete="email"
                  className="w-full rounded-lg py-2 pl-9 pr-3 text-sm outline-none transition-all focus:ring-2"
                  style={{
                    background: 'var(--color-surface-secondary)',
                    color: 'var(--color-text-primary)',
                    border: '1px solid var(--color-border)',
                  }}
                />
              </div>
            </div>

            {/* 密码 */}
            <div>
              <label
                className="mb-1 block text-xs font-medium"
                style={{ color: 'var(--color-text-secondary)' }}
              >
                密码
              </label>
              <div className="relative">
                <Lock
                  size={14}
                  className="absolute left-3 top-1/2 -translate-y-1/2"
                  style={{ color: 'var(--color-text-muted)' }}
                />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="至少 6 位"
                  autoComplete={isRegister ? 'new-password' : 'current-password'}
                  className="w-full rounded-lg py-2 pl-9 pr-9 text-sm outline-none transition-all focus:ring-2"
                  style={{
                    background: 'var(--color-surface-secondary)',
                    color: 'var(--color-text-primary)',
                    border: '1px solid var(--color-border)',
                  }}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2"
                  style={{ color: 'var(--color-text-muted)' }}
                >
                  {showPassword ? <EyeOff size={14} /> : <Eye size={14} />}
                </button>
              </div>
            </div>

            {/* 错误消息 */}
            {error && (
              <div
                className="rounded-lg px-3 py-2 text-xs"
                style={{
                  background: 'rgba(239,68,68,0.1)',
                  color: '#ef4444',
                  border: '1px solid rgba(239,68,68,0.2)',
                }}
              >
                {error}
              </div>
            )}

            {/* 提交按钮 */}
            <button
              type="submit"
              disabled={loading}
              className="flex w-full items-center justify-center gap-2 rounded-lg py-2.5 text-sm font-medium transition-all duration-200 hover:opacity-90 disabled:opacity-50"
              style={{
                background: 'var(--color-accent)',
                color: '#fff',
              }}
            >
              {loading ? (
                <>
                  <Loader2 size={14} className="animate-spin" />
                  处理中...
                </>
              ) : isRegister ? (
                '创建管理员账号'
              ) : (
                '登录'
              )}
            </button>
          </form>

          {/* 切换注册/登录 */}
          <div className="mt-4 text-center">
            <button
              onClick={() => {
                setIsRegister(!isRegister);
                setError('');
              }}
              className="text-xs transition-colors hover:underline"
              style={{ color: 'var(--color-accent)' }}
            >
              {isRegister ? '已有账号？去登录' : '没有账号？注册管理员'}
            </button>
          </div>

          {/* 提示 */}
          <p
            className="mt-3 text-center text-[10px] leading-relaxed"
            style={{ color: 'var(--color-text-muted)' }}
          >
            管理员账号可多人同时登录，未登录用户仅可查看
          </p>
        </div>
      </div>
    </div>
  );
}
