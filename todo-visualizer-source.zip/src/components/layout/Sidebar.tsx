import { Calendar, Layout, Settings, Users } from 'lucide-react';
import { useSettingStore } from '@/stores/useSettingStore';
import clsx from 'clsx';

const navItems = [
  { id: 'week' as const, icon: Calendar, label: '周视图' },
  { id: 'team' as const, icon: Users, label: '团队' },
  { id: 'templates' as const, icon: Layout, label: '模板库' },
  { id: 'settings' as const, icon: Settings, label: '设置' },
];

export function Sidebar() {
  const { activePage, setActivePage } = useSettingStore();

  return (
    <aside
      className="flex w-14 shrink-0 flex-col items-center gap-1 border-r py-3"
      style={{
        background: 'var(--color-surface)',
        borderColor: 'var(--color-border)',
      }}
    >
      {navItems.map(({ id, icon: Icon, label }) => (
        <button
          key={id}
          onClick={() => setActivePage(id)}
          className={clsx(
            'flex flex-col items-center gap-0.5 rounded-lg p-2 transition-all duration-200 premium w-11',
            activePage === id
              ? 'text-[var(--color-accent)] bg-[var(--color-accent-muted)]'
              : 'text-[var(--color-text-muted)] hover:text-[var(--color-text-secondary)] hover:bg-[var(--color-surface-secondary)]'
          )}
          title={label}
        >
          <Icon size={18} />
          <span className="text-[9px] leading-none font-medium">{label.slice(0, 2)}</span>
        </button>
      ))}
    </aside>
  );
}
