import { Undo2, Redo2, Save, Download, Users } from 'lucide-react';
import { ThemeToggle } from '@/components/ui/ThemeToggle';
import { useSettingStore } from '@/stores/useSettingStore';
import { useTeamStore } from '@/stores/useTeamStore';
import { useToastStore } from '@/stores/useToastStore';
import { historyManager } from '@/services/history';
import { exportAllData } from '@/services/dataDir';
import { Button } from '@/components/ui/Button';
import clsx from 'clsx';

export function Header() {
  const { activePage } = useSettingStore();
  const { members, activeMemberId, setActiveMember } = useTeamStore();

  const handleUndo = () => {
    const event = historyManager.undo();
    if (event) {
      console.log('Undo:', event.description);
      // TODO: 在后续任务中实现完整的 Undo 逻辑
    }
  };

  const handleRedo = () => {
    const event = historyManager.redo();
    if (event) {
      console.log('Redo:', event.description);
    }
  };

  const handleExport = () => {
    const json = exportAllData();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `work-capacity-backup-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <header
      className="flex h-12 shrink-0 items-center justify-between border-b px-4"
      style={{
        background: 'var(--color-surface)',
        borderColor: 'var(--color-border)',
      }}
    >
      {/* 左侧：品牌 */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2">
          <svg width="22" height="22" viewBox="0 0 32 32" fill="none" className="shrink-0">
            <rect width="32" height="32" rx="8" fill="var(--color-accent)" />
            <rect x="6" y="10" width="5" height="14" rx="1" fill="white" opacity="0.9" />
            <rect x="13.5" y="7" width="5" height="17" rx="1" fill="white" opacity="0.9" />
            <rect x="21" y="12" width="5" height="12" rx="1" fill="white" opacity="0.9" />
          </svg>
          <span className="text-sm font-semibold tracking-tight" style={{ color: 'var(--color-text-primary)' }}>
            Work Capacity
          </span>
        </div>
        <span
          className="rounded-md px-1.5 py-0.5 text-[10px] font-medium"
          style={{
            background: 'var(--color-accent-muted)',
            color: 'var(--color-accent)',
          }}
        >
          MVP
        </span>
      </div>

      {/* 中间：工具栏 */}
      <div className="flex items-center gap-0.5">
        <Button
          variant="ghost"
          size="sm"
          onClick={handleUndo}
          disabled={!historyManager.canUndo()}
          title="撤销 (Ctrl+Z)"
        >
          <Undo2 size={14} />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={handleRedo}
          disabled={!historyManager.canRedo()}
          title="重做 (Ctrl+Shift+Z)"
        >
          <Redo2 size={14} />
        </Button>
        <div className="mx-2 h-4 w-px" style={{ background: 'var(--color-border)' }} />
        <Button variant="ghost" size="sm" title="保存" onClick={() => {
          useToastStore.getState().show('数据已保存', 'success');
        }}>
          <Save size={14} />
        </Button>
        <Button variant="ghost" size="sm" onClick={handleExport} title="导出备份">
          <Download size={14} />
        </Button>
      </div>

      {/* 右侧：团队成员 + 设置 */}
      <div className="flex items-center gap-3">
        {/* 团队成员选择 */}
        <div className="flex items-center gap-0.5 rounded-lg p-0.5" style={{ background: 'var(--color-surface-secondary)' }}>
          <button
            onClick={() => setActiveMember(null)}
            className={clsx(
              'rounded-md px-2.5 py-1 text-[11px] font-medium transition-all duration-150',
              !activeMemberId
                ? 'bg-[var(--color-accent)] text-white shadow-sm'
                : 'text-[var(--color-text-muted)] hover:text-[var(--color-text-primary)]'
            )}
          >
            <Users size={12} className="inline mr-1" />
            全部
          </button>
          {members.map((m) => (
            <button
              key={m.id}
              onClick={() => setActiveMember(m.id)}
              className={clsx(
                'rounded-md px-2.5 py-1 text-[11px] font-medium transition-all duration-150',
                activeMemberId === m.id
                  ? 'bg-[var(--color-accent)] text-white shadow-sm'
                  : 'text-[var(--color-text-muted)] hover:text-[var(--color-text-primary)]'
              )}
            >
              <span
                className="mr-1 inline-block h-2 w-2 rounded-full align-middle"
                style={{ background: m.color }}
              />
              {m.name}
            </button>
          ))}
        </div>
        <ThemeToggle />
      </div>
    </header>
  );
}
