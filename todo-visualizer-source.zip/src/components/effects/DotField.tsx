import { useEffect, useRef, memo } from 'react';

const TWO_PI = Math.PI * 2;

interface DotData {
  ax: number; ay: number;
  sx: number; sy: number;
  vx: number; vy: number;
  x: number; y: number;
}

interface Props {
  dotRadius?: number;
  dotSpacing?: number;
  cursorRadius?: number;
  bulgeStrength?: number;
  glowRadius?: number;
  glowColor?: string;
  gradientFrom?: string;
  gradientTo?: string;
  waveAmplitude?: number;
  sparkle?: boolean;
}

const DotField = memo<Props>(({
  dotRadius = 3,
  dotSpacing = 22,
  cursorRadius = 350,
  bulgeStrength = 60,
  glowRadius = 140,
  glowColor = 'rgba(139,92,246,0.15)',
  gradientFrom = 'rgba(139,92,246,0.55)',
  gradientTo = 'rgba(99,102,241,0.25)',
  waveAmplitude = 0,
  sparkle = false,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const glowRef = useRef<SVGCircleElement>(null);
  const rafRef = useRef(0);
  const dotsRef = useRef<DotData[]>([]);
  const mouseRef = useRef({ x: -9999, y: -9999, prevX: -9999, prevY: -9999, speed: 0 });
  const sizeRef = useRef({ w: 0, h: 0 });
  const glowOpacity = useRef(0);
  const propsRef = useRef({ dotRadius, dotSpacing, cursorRadius, bulgeStrength, glowRadius, glowColor, gradientFrom, gradientTo, waveAmplitude, sparkle });
  propsRef.current = { dotRadius, dotSpacing, cursorRadius, bulgeStrength, glowRadius, glowColor, gradientFrom, gradientTo, waveAmplitude, sparkle };

  const GLOW_ID = useRef(`df-${Math.random().toString(36).slice(2,7)}`).current;

  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const ctx = canvas.getContext('2d', { alpha: true });
    if (!ctx) return;

    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    let resizeTimer: ReturnType<typeof setTimeout>;
    let frame = 0;

    function resize() {
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(build, 150);
    }

    function build() {
      const p = propsRef.current;
      const rect = container!.getBoundingClientRect();
      const w = rect.width || window.innerWidth;
      const h = rect.height || window.innerHeight;

      sizeRef.current = { w, h };
      canvas!.width = w * dpr;
      canvas!.height = h * dpr;
      canvas!.style.width = w + 'px';
      canvas!.style.height = h + 'px';
      ctx!.setTransform(dpr, 0, 0, dpr, 0, 0);

      const step = p.dotRadius + p.dotSpacing;
      const cols = Math.floor(w / step) + 1;
      const rows = Math.floor(h / step) + 1;
      const dots: DotData[] = [];

      for (let row = 0; row < rows; row++) {
        for (let col = 0; col < cols; col++) {
          const x = col * step + step / 2;
          const y = row * step + step / 2;
          dots.push({ ax: x, ay: y, sx: x, sy: y, vx: 0, vy: 0, x, y });
        }
      }
      dotsRef.current = dots;
    }

    function onMouseMove(e: MouseEvent) {
      mouseRef.current.x = e.clientX;
      mouseRef.current.y = e.clientY;
    }

    function updateSpeed() {
      const m = mouseRef.current;
      const dx = m.prevX - m.x;
      const dy = m.prevY - m.y;
      m.speed += (Math.sqrt(dx * dx + dy * dy) - m.speed) * 0.5;
      m.prevX = m.x;
      m.prevY = m.y;
    }

    const speedTimer = setInterval(updateSpeed, 30);

    function tick() {
      frame++;
      const { w, h } = sizeRef.current;
      if (w === 0 || h === 0) { rafRef.current = requestAnimationFrame(tick); return; }

      const dots = dotsRef.current;
      const p = propsRef.current;
      const m = mouseRef.current;
      const eng = Math.min(m.speed / 8, 1);
      const rad = p.dotRadius / 2;
      const cr = p.cursorRadius;
      const crSq = cr * cr;

      // 更新光晕位置
      glowOpacity.current += (eng - glowOpacity.current) * 0.08;
      const glow = glowRef.current;
      if (glow) {
        glow.setAttribute('cx', String(m.x));
        glow.setAttribute('cy', String(m.y));
        glow.style.opacity = String(glowOpacity.current);
      }

      ctx!.clearRect(0, 0, w, h);
      const grad = ctx!.createLinearGradient(0, 0, w, h);
      grad.addColorStop(0, p.gradientFrom);
      grad.addColorStop(1, p.gradientTo);
      ctx!.fillStyle = grad;
      ctx!.beginPath();

      for (let i = 0; i < dots.length; i++) {
        const d = dots[i];
        const dx = m.x - d.ax;
        const dy = m.y - d.ay;
        const distSq = dx * dx + dy * dy;

        if (distSq < crSq && eng > 0.01) {
          const dist = Math.sqrt(distSq);
          const t = 1 - dist / cr;
          const push = t * t * p.bulgeStrength * eng;
          const angle = Math.atan2(dy, dx);
          d.sx += (d.ax - Math.cos(angle) * push - d.sx) * 0.12;
          d.sy += (d.ay - Math.sin(angle) * push - d.sy) * 0.12;
        } else {
          d.sx += (d.ax - d.sx) * 0.08;
          d.sy += (d.ay - d.sy) * 0.08;
        }

        if (p.waveAmplitude > 0) {
          const waveY = Math.sin(d.ax * 0.03 + frame * 0.02) * p.waveAmplitude;
          ctx!.moveTo(d.sx + rad + Math.cos(d.ay * 0.03 + frame * 0.014) * p.waveAmplitude * 0.5, d.sy + rad + waveY);
        } else {
          ctx!.moveTo(d.sx + rad, d.sy);
        }
        ctx!.arc(d.sx, d.sy, rad, 0, TWO_PI);
      }

      ctx!.fill();
      rafRef.current = requestAnimationFrame(tick);
    }

    build();
    window.addEventListener('resize', resize);
    window.addEventListener('mousemove', onMouseMove, { passive: true });
    rafRef.current = requestAnimationFrame(tick);

    return () => {
      cancelAnimationFrame(rafRef.current);
      clearInterval(speedTimer);
      clearTimeout(resizeTimer);
      window.removeEventListener('resize', resize);
      window.removeEventListener('mousemove', onMouseMove);
    };
  }, []);

  return (
    <div
      ref={containerRef}
      style={{
        position: 'absolute',
        inset: 0,
        width: '100%',
        height: '100%',
        pointerEvents: 'none',
        overflow: 'hidden',
        background: 'transparent',
      }}
    >
      <canvas
        ref={canvasRef}
        style={{
          display: 'block',
          position: 'absolute',
          top: 0,
          left: 0,
          width: '100%',
          height: '100%',
        }}
      />
      <svg
        style={{
          position: 'absolute',
          inset: 0,
          width: '100%',
          height: '100%',
          pointerEvents: 'none',
        }}
      >
        <defs>
          <radialGradient id={GLOW_ID}>
            <stop offset="0%" stopColor={glowColor} />
            <stop offset="100%" stopColor="transparent" />
          </radialGradient>
        </defs>
        <circle
          ref={glowRef}
          cx="-9999" cy="-9999"
          r={glowRadius}
          fill={`url(#${GLOW_ID})`}
          style={{ willChange: 'opacity', opacity: 0 }}
        />
      </svg>
    </div>
  );
});

DotField.displayName = 'DotField';
export default DotField;
