import { useRef, type ReactNode, type CSSProperties } from 'react';
import { motion, useMotionValue, useSpring, useMotionTemplate } from 'framer-motion';

interface TiltWrapperProps {
  children: ReactNode;
  rotateAmplitude?: number;
  scaleOnHover?: number;
  glareColor?: string;
  className?: string;
  style?: CSSProperties;
  outerRef?: React.Ref<HTMLDivElement>;
}

const springConfig = { damping: 30, stiffness: 100, mass: 2 };

/**
 * TiltWrapper — 3D 倾斜悬浮卡片包裹器
 * 基于 framer-motion spring 实现鼠标跟踪的 3D 倾斜 + 光泽扫过效果
 */
export function TiltWrapper({
  children,
  rotateAmplitude = 12,
  scaleOnHover = 1.03,
  glareColor = 'rgba(139,92,246,0.08)',
  className = '',
  style,
  outerRef,
}: TiltWrapperProps) {
  const containerRef = useRef<HTMLDivElement>(null);

  const rotateX = useSpring(useMotionValue(0), springConfig);
  const rotateY = useSpring(useMotionValue(0), springConfig);
  const scale = useSpring(1, springConfig);
  const glareOpacity = useSpring(0, { damping: 30, stiffness: 200, mass: 1 });
  const glareX = useMotionValue(50);
  const glareY = useMotionValue(50);

  const glareBg = useMotionTemplate`radial-gradient(circle at ${glareX}% ${glareY}%, ${glareColor}, transparent 55%)`;

  function handleMouse(e: React.MouseEvent) {
    const rect = containerRef.current?.getBoundingClientRect();
    if (!rect) return;

    const offsetX = e.clientX - rect.left - rect.width / 2;
    const offsetY = e.clientY - rect.top - rect.height / 2;

    rotateX.set((offsetY / (rect.height / 2)) * -rotateAmplitude);
    rotateY.set((offsetX / (rect.width / 2)) * rotateAmplitude);

    glareX.set(((e.clientX - rect.left) / rect.width) * 100);
    glareY.set(((e.clientY - rect.top) / rect.height) * 100);
  }

  function handleMouseEnter() {
    scale.set(scaleOnHover);
    glareOpacity.set(1);
  }

  function handleMouseLeave() {
    scale.set(1);
    rotateX.set(0);
    rotateY.set(0);
    glareOpacity.set(0);
  }

  return (
    <div
      ref={(node) => {
        (containerRef as React.MutableRefObject<HTMLDivElement | null>).current = node;
        if (typeof outerRef === 'function') outerRef(node);
        else if (outerRef) (outerRef as React.MutableRefObject<HTMLDivElement | null>).current = node;
      }}
      className={className}
      style={{ perspective: 600, ...style }}
      onMouseMove={handleMouse}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
    >
      <motion.div
        style={{
          rotateX,
          rotateY,
          scale,
          transformStyle: 'preserve-3d',
          position: 'relative',
          width: '100%',
          height: '100%',
        }}
      >
        {children}
        {/* 光泽扫过层 */}
        <motion.div
          className="pointer-events-none absolute inset-0 z-30 rounded-[inherit]"
          style={{ backgroundImage: glareBg, opacity: glareOpacity }}
        />
      </motion.div>
    </div>
  );
}
