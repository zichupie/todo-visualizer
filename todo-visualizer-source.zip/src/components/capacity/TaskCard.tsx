import { useCallback, useRef, useState, useEffect } from 'react';
import { GripVertical, Lock, Trash2, Pencil } from 'lucide-react';
import { useDraggable } from '@dnd-kit/core';
import { useTaskStore } from '@/stores/useTaskStore';
import { useSettingStore } from '@/stores/useSettingStore';
import { TemplateIcon } from '@/components/template/TemplateIcon';
import { Badge } from '@/components/ui/Badge';
import { formatDurationShort, durationToPx } from '@/utils/duration';
import { STATUS_LABELS } from '@/types';
import type { Task } from '@/types';

interface TaskCardProps {
  task: Task;
  isOverCapacity?: boolean;
  compact?: boolean;
}

export function TaskCard({ task, isOverCapacity, compact }: TaskCardProps) {
  const { updateTask, openDrawer } = useTaskStore();
  const { settings } = useSettingStore();
  const [isResizing, setIsResizing] = useState(false);
  const [resizeDeltaPx, setResizeDeltaPx] = useState(0);
  const [showMenu, setShowMenu] = useState(false);
  const [editingName, setEditingName] = useState(false);
  const [nameDraft, setNameDraft] = useState(task.name);
  const startYRef = useRef(0);
  const startDurationRef = useRef(0);
  const deltaRef = useRef(0); // 当前拖拽增量（px）
  const moveHandlerRef = useRef<((e: Event) => void) | null>(null);
  const upHandlerRef = useRef<((e: Event) => void) | null>(null);

  // 组件卸载时清理 resize 监听器，防止内存泄漏
  useEffect(() => {
    return () => {
      if (moveHandlerRef.current) document.removeEventListener('mousemove', moveHandlerRef.current);
      if (upHandlerRef.current) document.removeEventListener('mouseup', upHandlerRef.current);
      if (moveHandlerRef.current) document.removeEventListener('touchmove', moveHandlerRef.current);
      if (upHandlerRef.current) document.removeEventListener('touchend', upHandlerRef.current);
    };
  }, []);

  const pxPerHour = settings.pxPerHour;
  const visualHeight = Math.max(40, durationToPx(task.duration, pxPerHour) + resizeDeltaPx);

  // 拖拽
  const {
    attributes,
    listeners,
    setNodeRef: setDragRef,
    transform,
    isDragging,
  } = useDraggable({
    id: task.id,
    data: { type: 'task', task },
    disabled: task.locked,
  });

  const style: React.CSSProperties = {
    height: `${visualHeight}px`,
    boxSizing: 'border-box',
    transform: transform
      ? `translate3d(${transform.x}px, ${transform.y}px, 0)`
      : undefined,
    opacity: isDragging ? 0.5 : 1,
    zIndex: isDragging || isResizing ? 20 : 1,
    touchAction: 'none',
    background: task.color + '50',
    border: `1px solid ${task.color}70`,
  };

  // 高度调整
  const handleResizeStart = useCallback(
    (e: React.MouseEvent | React.TouchEvent) => {
      if (task.locked) return;
      e.preventDefault();
      e.stopPropagation();

      const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
      setIsResizing(true);
      startYRef.current = clientY;
      startDurationRef.current = task.duration;
      setResizeDeltaPx(0);

      const handleMove = (moveEvent: MouseEvent | TouchEvent) => {
        const moveY = 'touches' in moveEvent ? moveEvent.touches[0].clientY : moveEvent.clientY;
        const deltaPx = moveY - startYRef.current;
        deltaRef.current = deltaPx;
        // 本地状态驱动视觉高度，不触发 store 重渲染
        setResizeDeltaPx(deltaPx);
      };

      const handleUp = () => {
        setIsResizing(false);
        setResizeDeltaPx(0);

        // 松手时一次性写入 store
        const deltaMinutes = (deltaRef.current / pxPerHour) * 60;
        let rawDuration = startDurationRef.current + deltaMinutes;
        let newDuration = Math.round(rawDuration / 30) * 30; // 30分钟步进
        newDuration = Math.max(30, Math.min(1440, newDuration));
        updateTask(task.id, { duration: newDuration });

        document.removeEventListener('mousemove', handleMove);
        document.removeEventListener('mouseup', handleUp);
        document.removeEventListener('touchmove', handleMove);
        document.removeEventListener('touchend', handleUp);
      };

      document.addEventListener('mousemove', handleMove);
      document.addEventListener('mouseup', handleUp);
      document.addEventListener('touchmove', handleMove);
      document.addEventListener('touchend', handleUp);
      moveHandlerRef.current = handleMove;
      upHandlerRef.current = handleUp;
    },
    [task, pxPerHour, updateTask]
  );

  return (
    <div
      ref={setDragRef}
      style={style}
      className="group/handle relative mx-1 flex select-none flex-col overflow-hidden rounded-lg transition-shadow duration-150 hover:shadow-md"
      onContextMenu={(e) => {
        e.preventDefault();
        e.stopPropagation();
        setShowMenu(true);
      }}
      onDoubleClick={() => {
        if (!isResizing) openDrawer(task.id);
      }}
    >
      <div className="flex flex-1 flex-col px-1.5 py-0.5">
        {/* 右上角删除按钮 */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            const { deleteTask } = useTaskStore.getState();
            deleteTask(task.id);
          }}
          className="absolute right-1 top-1 rounded p-0.5 opacity-0 group-hover/handle:opacity-100 transition-opacity hover:bg-[var(--color-danger-muted)] z-20"
          title="删除任务"
        >
          <Trash2 size={11} style={{ color: 'var(--color-text-muted)' }} />
        </button>

        {/* 头部：拖拽手柄 + 图标 + 名称 */}
        <div className="mb-1 flex items-center gap-1.5 pr-4">
          <div
            {...(!task.locked ? { ...listeners, ...attributes } : {})}
            className="cursor-grab active:cursor-grabbing touch-none"
          >
            <GripVertical
              size={12}
              className={task.locked ? 'opacity-20' : 'opacity-40'}
              style={{ color: 'var(--color-text-muted)' }}
            />
          </div>
          <TemplateIcon name={task.iconValue} size={12} />
          <span
            className="truncate text-[11px] font-medium leading-tight"
            style={{ color: 'var(--color-text-primary)' }}
            title={task.name}
          >
            {compact ? task.name[0] || task.name : task.name}
          </span>
          {task.locked && (
            <Lock size={10} style={{ color: 'var(--color-text-muted)' }} />
          )}
        </div>

        {/* 时长标签 — 拖拽中显示实时值 */}
        <div className="flex items-center gap-1.5">
          <Badge variant="accent" size="sm">
            {isResizing
              ? formatDurationShort(Math.round((task.duration + (deltaRef.current / pxPerHour * 60)) / 30) * 30)
              : formatDurationShort(task.duration)
            }
          </Badge>
          <span className="text-[9px]" style={{ color: 'var(--color-text-muted)' }}>
            {STATUS_LABELS[task.status]}
          </span>
        </div>
      </div>

      {/* 超容量指示 */}
      {isOverCapacity && (
        <div
          className="absolute bottom-0 left-0 right-0 h-1"
          style={{ background: 'var(--color-danger)' }}
        />
      )}

      {/* 调整高度手柄 — 更明显 */}
      {!task.locked && (
        <div
          onMouseDown={handleResizeStart}
          onTouchStart={handleResizeStart}
          className="absolute bottom-0 left-0 right-0 flex h-5 cursor-s-resize items-end justify-center pb-0.5 group/handle"
        >
          <div
            className="h-1 w-10 rounded-full opacity-0 group-hover/handle:opacity-100 transition-opacity"
            style={{ background: task.color }}
          />
          <div
            className="absolute bottom-0 left-1/2 -translate-x-1/2 h-0.5 w-16 rounded-full opacity-0 group-hover/handle:opacity-60 transition-opacity"
            style={{ background: 'var(--color-text-muted)' }}
          />
        </div>
      )}

      {/* 右键菜单 — 右侧浮窗 */}
      {showMenu && (
        <>
          {/* 点击外部关闭 */}
          <div
            className="fixed inset-0 z-40"
            onClick={(e) => { e.stopPropagation(); setShowMenu(false); }}
          />
          <div
            className="absolute left-full top-0 z-50 ml-1 flex min-w-[120px] flex-col gap-0.5 rounded-lg border p-1 shadow-lg"
            style={{
              background: 'var(--color-surface)',
              borderColor: 'var(--color-border)',
            }}
          >
            {editingName ? (
              <div className="flex items-center gap-1 px-1 py-0.5" onClick={(e) => e.stopPropagation()}>
                <input
                  value={nameDraft}
                  onChange={(e) => setNameDraft(e.target.value)}
                  className="w-24 rounded border px-1.5 py-1 text-[11px] outline-none"
                  style={{ background: 'var(--color-surface)', borderColor: 'var(--color-accent)', color: 'var(--color-text-primary)' }}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      updateTask(task.id, { name: nameDraft || task.name });
                      setEditingName(false);
                      setShowMenu(false);
                    }
                    if (e.key === 'Escape') { setEditingName(false); setNameDraft(task.name); }
                  }}
                  autoFocus
                />
              </div>
            ) : (
              <>
                <button
                  onClick={(e) => { e.stopPropagation(); setEditingName(true); setNameDraft(task.name); }}
                  className="flex items-center gap-2 rounded-md px-2.5 py-1.5 text-[11px] font-medium transition-colors hover:bg-[var(--color-surface-secondary)]"
                  style={{ color: 'var(--color-text-primary)' }}
                >
                  <Pencil size={12} />
                  修改名称
                </button>
              </>
            )}
          </div>
        </>
      )}
    </div>
  );
}
