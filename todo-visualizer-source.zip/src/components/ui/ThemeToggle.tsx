import { Sun, Moon, Monitor } from 'lucide-react';
import { useSettingStore } from '@/stores/useSettingStore';
import type { ThemeMode } from '@/types';
import clsx from 'clsx';

const themes: { mode: ThemeMode; icon: typeof Sun; label: string }[] = [
  { mode: 'light', icon: Sun, label: '浅色' },
  { mode: 'dark', icon: Moon, label: '深色' },
  { mode: 'system', icon: Monitor, label: '系统' },
];

export function ThemeToggle() {
  const { settings, setTheme } = useSettingStore();

  return (
    <div className="flex items-center gap-0.5 rounded-lg p-0.5" style={{ background: 'var(--color-surface-secondary)' }}>
      {themes.map(({ mode, icon: Icon, label }) => (
        <button
          key={mode}
          onClick={() => setTheme(mode)}
          className={clsx(
            'flex items-center justify-center rounded-md p-1.5 transition-all duration-200 premium',
            settings.theme === mode
              ? 'bg-[var(--color-surface)] shadow-sm text-[var(--color-accent)]'
              : 'text-[var(--color-text-muted)] hover:text-[var(--color-text-secondary)]'
          )}
          title={label}
          aria-label={`切换${label}主题`}
        >
          <Icon size={16} />
        </button>
      ))}
    </div>
  );
}
