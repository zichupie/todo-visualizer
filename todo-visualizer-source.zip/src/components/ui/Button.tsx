import clsx from 'clsx';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  size?: 'sm' | 'md' | 'lg';
}

export function Button({
  variant = 'primary',
  size = 'md',
  className,
  children,
  ...props
}: ButtonProps) {
  return (
    <button
      className={clsx(
        'inline-flex items-center justify-center font-medium transition-all duration-200 premium',
        'rounded-lg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--color-accent)]',
        'disabled:opacity-50 disabled:cursor-not-allowed',
        'active:scale-[0.97]',
        {
          'bg-[var(--color-accent)] text-white hover:bg-[var(--color-accent-hover)] shadow-sm':
            variant === 'primary',
          'bg-[var(--color-surface-secondary)] text-[var(--color-text-primary)] hover:bg-[var(--color-border)] border border-[var(--color-border)]':
            variant === 'secondary',
          'text-[var(--color-text-secondary)] hover:bg-[var(--color-surface-secondary)] hover:text-[var(--color-text-primary)]':
            variant === 'ghost',
          'bg-[var(--color-danger)] text-white hover:opacity-90':
            variant === 'danger',
        },
        {
          'px-2.5 py-1.5 text-xs gap-1': size === 'sm',
          'px-4 py-2 text-sm gap-1.5': size === 'md',
          'px-5 py-2.5 text-sm gap-2': size === 'lg',
        },
        className
      )}
      {...props}
    >
      {children}
    </button>
  );
}
