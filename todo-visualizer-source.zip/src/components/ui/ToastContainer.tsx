import { Check, X, Info, AlertTriangle } from 'lucide-react';
import { useToastStore } from '@/stores/useToastStore';

export function ToastContainer() {
  const { toasts, dismiss } = useToastStore();

  if (toasts.length === 0) return null;

  return (
    <div className="pointer-events-none fixed bottom-12 left-1/2 z-[99999] flex -translate-x-1/2 flex-col items-center gap-2">
      {toasts.map((toast) => (
        <div
          key={toast.id}
          onClick={() => dismiss(toast.id)}
          className="pointer-events-auto flex animate-slide-up items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-medium shadow-lg backdrop-blur-md transition-all duration-200 hover:scale-105 cursor-pointer"
          style={{
            background: toast.type === 'error'
              ? 'rgba(239,68,68,0.9)'
              : toast.type === 'info'
                ? 'rgba(99,102,241,0.9)'
                : 'rgba(34,197,94,0.9)',
            color: '#fff',
            border: '1px solid rgba(255,255,255,0.15)',
            animation: 'toastIn 0.3s cubic-bezier(0.16,1,0.3,1)',
          }}
        >
          {toast.type === 'success' && <Check size={16} strokeWidth={2.5} />}
          {toast.type === 'error' && <AlertTriangle size={16} strokeWidth={2.5} />}
          {toast.type === 'info' && <Info size={16} strokeWidth={2.5} />}
          {toast.message}
          <button
            onClick={(e) => { e.stopPropagation(); dismiss(toast.id); }}
            className="ml-1 rounded-full p-0.5 hover:bg-white/20 transition-colors"
          >
            <X size={12} />
          </button>
        </div>
      ))}
    </div>
  );
}
