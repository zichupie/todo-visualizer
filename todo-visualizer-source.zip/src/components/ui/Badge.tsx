import clsx from 'clsx';

interface BadgeProps {
  children: React.ReactNode;
  variant?: 'default' | 'accent' | 'success' | 'warning' | 'danger';
  size?: 'sm' | 'md';
  className?: string;
}

export function Badge({ children, variant = 'default', size = 'sm', className }: BadgeProps) {
  return (
    <span
      className={clsx(
        'inline-flex items-center rounded-md font-medium',
        {
          'px-1.5 py-0.5 text-[10px]': size === 'sm',
          'px-2 py-1 text-xs': size === 'md',
          'bg-[var(--color-surface-secondary)] text-[var(--color-text-secondary)]': variant === 'default',
          'bg-[var(--color-accent-muted)] text-[var(--color-accent)]': variant === 'accent',
          'bg-[var(--color-success-muted)] text-[var(--color-success)]': variant === 'success',
          'bg-[var(--color-warning-muted)] text-[var(--color-warning)]': variant === 'warning',
          'bg-[var(--color-danger-muted)] text-[var(--color-danger)]': variant === 'danger',
        },
        className
      )}
    >
      {children}
    </span>
  );
}
