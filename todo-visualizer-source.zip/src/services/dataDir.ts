import type { AppSettings } from '@/types';
import { useToastStore } from '@/stores/useToastStore';

const STORAGE_KEY = 'wce_settings';
const DB_NAME = 'wce_data';

/**
 * 获取数据存储目录（仅供显示）
 */
export function getDataDir(): string {
  return '';
}

/**
 * 获取存储键名（带命名空间）
 */
export function getStorageKey(key: string): string {
  return `${DB_NAME}_${key}`;
}

// ── 服务端文件存储 API ──
const API_BASE = window.location.origin;

async function apiLoad(key: string) {
  try {
    const res = await fetch(`${API_BASE}/api/data?key=${encodeURIComponent(key)}`);
    if (!res.ok) return null;
    const data = await res.json();
    return data; // null if not exists
  } catch {
    return undefined; // undefined = API unavailable (fall back to localStorage)
  }
}

async function apiSave(key: string, data: unknown): Promise<boolean> {
  try {
    const res = await fetch(`${API_BASE}/api/data`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ key, data }),
    });
    return res.ok;
  } catch {
    return false;
  }
}

/**
 * 安全读取数据（优先 localStorage，初始时从 API 同步）
 */
export function loadFromStorage<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(getStorageKey(key));
    if (raw === null) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

/**
 * 安全写入数据（localStorage + 服务端文件双写）
 * @returns true 表示写入成功
 */
export function saveToStorage<T>(key: string, data: T): boolean {
  try {
    // 写入 localStorage（即时生效）
    localStorage.setItem(getStorageKey(key), JSON.stringify(data));
    // 异步写入服务端文件系统（不阻塞 UI）
    apiSave(getStorageKey(key), data).then((ok) => {
      if (ok) notifySave();
    });
    return true;
  } catch (err) {
    console.error('Failed to save:', err);
    return false;
  }
}

/**
 * 从服务端同步数据到 localStorage（启动时调用）
 * @returns true 表示有从服务端加载到数据
 */
export async function syncFromServer(key: string): Promise<boolean> {
  const result = await apiLoad(getStorageKey(key));
  if (result === undefined || result === null) return false;
  try {
    localStorage.setItem(getStorageKey(key), JSON.stringify(result));
    return true;
  } catch {
    return false;
  }
}

/**
 * 删除 localStorage 项
 */
export function removeFromStorage(key: string): void {
  try {
    localStorage.removeItem(getStorageKey(key));
  } catch (err) {
    console.error('Failed to remove:', err);
  }
}

/**
 * 加载设置
 */
export function loadSettings(): AppSettings {
  return loadFromStorage<AppSettings>(STORAGE_KEY, {
    id: 'default',
    defaultCapacity: 480,
    pxPerHour: 50,
    theme: 'system',
    lastBackupAt: null,
    dataDir: getDataDir(),
    backupDir: '',
    autoBackup: false,
  });
}

/**
 * 保存设置
 */
export function saveSettings(settings: AppSettings): void {
  saveToStorage(STORAGE_KEY, settings);
}

/**
 * 导出全部数据为 JSON
 */
export function exportAllData(): string {
  const data: Record<string, unknown> = {};
  const keys = [
    'wce_settings', 'wce_templates', 'wce_template_categories',
    'wce_tasks', 'wce_schedules', 'wce_history',
  ];

  for (const key of keys) {
    const raw = localStorage.getItem(key);
    if (raw) {
      try { data[key.replace('wce_', '')] = JSON.parse(raw); }
      catch { data[key.replace('wce_', '')] = raw; }
    }
  }

  return JSON.stringify({ version: '0.1.0', exportedAt: new Date().toISOString(), data }, null, 2);
}

/**
 * 从 JSON 导入数据
 */
export function importAllData(json: string, mode: 'merge' | 'overwrite' = 'overwrite'): boolean {
  try {
    const parsed = JSON.parse(json);
    if (!parsed.data || !parsed.version) throw new Error('Invalid backup format');

    const prefix = 'wce_';
    if (mode === 'overwrite') {
      const allKeys = Object.keys(localStorage).filter((k) => k.startsWith(prefix));
      for (const key of allKeys) localStorage.removeItem(key);
    }

    for (const [key, value] of Object.entries(parsed.data)) {
      const fullKey = `${prefix}${key}`;
      localStorage.setItem(fullKey, JSON.stringify(value));
      // Also sync to server
      apiSave(fullKey, value);
    }
    return true;
  } catch (err) {
    console.error('Import failed:', err);
    return false;
  }
}

/**
 * 检查是否需要备份提醒
 */
export function shouldRemindBackup(lastBackupAt: string | null): boolean {
  if (!lastBackupAt) return true;
  const last = new Date(lastBackupAt).getTime();
  const now = Date.now();
  const sevenDays = 7 * 24 * 60 * 60 * 1000;
  return now - last > sevenDays;
}

// ── 保存通知节流 ──
let _lastNotify = 0;
const NOTIFY_THROTTLE = 1500;

function notifySave() {
  const now = Date.now();
  if (now - _lastNotify < NOTIFY_THROTTLE) return;
  _lastNotify = now;
  setTimeout(() => {
    useToastStore.getState()?.show('数据已保存到本地文件', 'success');
  }, 0);
}
