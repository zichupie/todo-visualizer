import { v4 as uuidv4 } from 'uuid';
import type { HistoryEvent, HistoryEventType } from '@/types';
import { loadFromStorage, saveToStorage } from '@/services/dataDir';

const HISTORY_KEY = 'wce_history';
const MAX_HISTORY_DEPTH = 50;

/**
 * 历史记录管理器：支持 Undo/Redo，持久化
 */
class HistoryManager {
  private events: HistoryEvent[] = [];
  private undoStack: HistoryEvent[] = [];
  private redoStack: HistoryEvent[] = [];

  constructor() {
    this.load();
  }

  private load(): void {
    this.events = loadFromStorage<HistoryEvent[]>(HISTORY_KEY, []);
  }

  private save(): void {
    saveToStorage(HISTORY_KEY, this.events);
  }

  /**
   * 记录一条操作
   */
  record(type: HistoryEventType, payload: unknown, description: string): void {
    const event: HistoryEvent = {
      id: uuidv4(),
      type,
      payload: JSON.stringify(payload),
      description,
      createdAt: new Date().toISOString(),
    };

    this.undoStack.push(event);
    this.redoStack = []; // 新操作清除 redo 栈

    // 限制栈深度
    if (this.undoStack.length > MAX_HISTORY_DEPTH) {
      this.undoStack.shift();
    }

    this.events.unshift(event);
    // 限制总记录数
    if (this.events.length > MAX_HISTORY_DEPTH * 2) {
      this.events = this.events.slice(0, MAX_HISTORY_DEPTH * 2);
    }

    this.save();
  }

  /**
   * 撤销
   */
  undo(): HistoryEvent | null {
    const event = this.undoStack.pop();
    if (event) {
      this.redoStack.push(event);
      return event;
    }
    return null;
  }

  /**
   * 重做
   */
  redo(): HistoryEvent | null {
    const event = this.redoStack.pop();
    if (event) {
      this.undoStack.push(event);
      return event;
    }
    return null;
  }

  /**
   * 获取所有事件
   */
  getAll(): HistoryEvent[] {
    return this.events;
  }

  /**
   * 是否可以撤销
   */
  canUndo(): boolean {
    return this.undoStack.length > 0;
  }

  /**
   * 是否可以重做
   */
  canRedo(): boolean {
    return this.redoStack.length > 0;
  }

  /**
   * 清空历史
   */
  clear(): void {
    this.events = [];
    this.undoStack = [];
    this.redoStack = [];
    this.save();
  }
}

export const historyManager = new HistoryManager();
