import { createClient } from '@supabase/supabase-js';
import type { SupabaseClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

let _client: SupabaseClient | null = null;

function getClient(): SupabaseClient {
  if (!_client) {
    // 未配置时用占位值，避免 createClient 抛错
    // 调用方必须通过 isSupabaseConfigured() 先检查再使用
    const url = supabaseUrl || 'https://placeholder.local';
    const key = supabaseAnonKey || 'placeholder';
    _client = createClient(url, key, {
      auth: {
        autoRefreshToken: true,
        persistSession: true,
        detectSessionInUrl: false,
      },
      realtime: {
        params: {
          eventsPerSecond: 10,
        },
      },
    });
  }
  return _client;
}

/**
 * 懒加载 Supabase 客户端
 * 
 * 使用 Proxy 保持原有 API：supabase.auth.getSession() 等
 * 实际客户端在首次访问时才创建，避免模块顶层 createClient('') 抛错
 * 
 * ⚠️ 调用任何方法前必须通过 isSupabaseConfigured() 检查配置状态
 */
export const supabase = new Proxy({} as SupabaseClient, {
  get(_target, prop, _receiver) {
    return Reflect.get(getClient(), prop);
  },
});

/** 检查 Supabase 是否已正确配置 */
export function isSupabaseConfigured(): boolean {
  return Boolean(supabaseUrl && supabaseAnonKey);
}
