import { useEffect, useMemo } from 'react';
import { AppShell } from '@/components/layout/AppShell';
import { WeekView } from '@/pages/WeekView';
import { TemplatePage } from '@/pages/TemplatePage';
import { SettingsPage } from '@/pages/SettingsPage';
import { TeamPage } from '@/pages/TeamPage';
import { AuthModal } from '@/components/auth/AuthModal';
import { Aurora } from '@/components/effects/Aurora';
import { ToastContainer } from '@/components/ui/ToastContainer';
import { useSettingStore } from '@/stores/useSettingStore';
import { useTemplateStore } from '@/stores/useTemplateStore';
import { useTaskStore } from '@/stores/useTaskStore';
import { useScheduleStore } from '@/stores/useScheduleStore';
import { useQuickTaskStore } from '@/stores/useQuickTaskStore';
import { useTeamStore } from '@/stores/useTeamStore';
import { useAuthStore } from '@/stores/useAuthStore';
import { syncFromServer, getStorageKey } from '@/services/dataDir';

export function App() {
  const { activePage, init, initialized, settings } = useSettingStore();
  const isDark = settings.theme === 'dark' || (settings.theme === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);
  const auroraColors = useMemo(() =>
    isDark ? ['#5227FF', '#8B5CF6', '#7C3AED'] : ['#ffffff', '#c8e6c9', '#a5d6a7'],
    [isDark]
  );
  const auroraBlend = isDark ? 0.35 : 0.55;
  const auroraAmplitude = isDark ? 1.0 : 1.3;

  // 初始化所有 stores
  useEffect(() => {
    async function bootstrap() {
      // 从服务端文件系统同步数据（仅 HTTP 环境下生效）
      const rawKeys = ['wce_settings', 'templates', 'template_categories', 'tasks', 'schedules', 'history', 'quick_tasks', 'team'];
      await Promise.all(rawKeys.map((k) => syncFromServer(getStorageKey(k))));
      // 初始化 stores
      init();
      useAuthStore.getState().initialize();
      useTemplateStore.getState().load();
      useTaskStore.getState().load();
      useScheduleStore.getState().load();
      useQuickTaskStore.getState().load();
      useTeamStore.getState().load();
    }
    bootstrap();
  }, [init]);

  // 键盘快捷键
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ctrl+Z: Undo
      if ((e.ctrlKey || e.metaKey) && e.key === 'z' && !e.shiftKey) {
        e.preventDefault();
        // Undo logic - implemented in Header
      }
      // Ctrl+Shift+Z: Redo
      if ((e.ctrlKey || e.metaKey) && e.key === 'z' && e.shiftKey) {
        e.preventDefault();
        // Redo logic
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  if (!initialized) {
    return (
      <div className="flex h-screen items-center justify-center bg-[var(--color-surface)]">
        <div className="animate-pulse-soft text-sm" style={{ color: 'var(--color-text-muted)' }}>
          加载中...
        </div>
      </div>
    );
  }

  return (
    <>
      <Aurora
        colorStops={auroraColors}
        blend={auroraBlend}
        amplitude={auroraAmplitude}
        speed={0.3}
      />
      <AppShell>
        {activePage === 'week' && <WeekView />}
        {activePage === 'team' && <TeamPage />}
        {activePage === 'templates' && <TemplatePage />}
        {activePage === 'settings' && <SettingsPage />}
        <AuthModal />
      </AppShell>
      <ToastContainer />
    </>
  );
}
