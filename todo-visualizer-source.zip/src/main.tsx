import React from 'react';
import ReactDOM from 'react-dom/client';
import { App } from './App';
import './index.css';

// ── 全局鼠标光晕追踪 ──
// 缓动跟随鼠标位置，写入 :root 的 --mx/--my
(() => {
  let mx = -9999, my = -9999; // 目标位置
  let cx = -9999, cy = -9999; // 当前位置（带缓动）
  const root = document.documentElement;
  document.addEventListener('mousemove',
    (e) => { mx = e.clientX; my = e.clientY; },
    { passive: true }
  );
  function tick() {
    cx += (mx - cx) * 0.06;
    cy += (my - cy) * 0.06;
    root.style.setProperty('--mx', cx + 'px');
    root.style.setProperty('--my', cy + 'px');
    requestAnimationFrame(tick);
  }
  tick();
})();

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
