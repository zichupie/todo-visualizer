import { useState, useMemo } from 'react';
import { Search, Plus, FolderPlus, X } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Modal } from '@/components/ui/Modal';
import { TemplateCard } from '@/components/template/TemplateCard';
import { TemplateFormModal } from '@/components/template/TemplateFormModal';
import { useTemplateStore } from '@/stores/useTemplateStore';
import type { Template } from '@/types';

/* ===== 主模板页面 ===== */
export function TemplatePage() {
  const {
    templates,
    categories,
    selectedCategoryId,
    addCategory,
    renameCategory,
    deleteCategory,
    setSelectedCategory,
  } = useTemplateStore();

  const [searchQuery, setSearchQuery] = useState('');
  const [formOpen, setFormOpen] = useState(false);
  const [categoryModalOpen, setCategoryModalOpen] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<Template | null>(null);
  const [newCategoryName, setNewCategoryName] = useState('');
  const [editingCategoryId, setEditingCategoryId] = useState<string | null>(null);
  const [editingCategoryName, setEditingCategoryName] = useState('');

  // 筛选模板
  const filteredTemplates = useMemo(() => {
    let list = templates;
    if (selectedCategoryId) list = list.filter((t) => t.categoryId === selectedCategoryId);
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter((t) => t.name.toLowerCase().includes(q));
    }
    return list;
  }, [templates, selectedCategoryId, searchQuery]);

  const handleNewTemplate = () => { setEditingTemplate(null); setFormOpen(true); };
  const handleEditTemplate = (template: Template) => { setEditingTemplate(template); setFormOpen(true); };
  const handleFormClose = () => { setFormOpen(false); setEditingTemplate(null); };
  const handleAddCategory = () => {
    if (!newCategoryName.trim()) return;
    addCategory(newCategoryName.trim());
    setNewCategoryName('');
    setCategoryModalOpen(false);
  };
  const handleStartRename = (id: string, currentName: string) => {
    setEditingCategoryId(id);
    setEditingCategoryName(currentName);
  };
  const handleSaveRename = (id: string) => {
    if (editingCategoryName.trim()) renameCategory(id, editingCategoryName.trim());
    setEditingCategoryId(null);
  };

  return (
    <div className="flex h-full flex-col">

      {/* ==================== 模板标题栏 ==================== */}
      <div className="flex shrink-0 items-center justify-between border-b px-5 py-3" style={{ borderColor: 'var(--color-border-subtle)' }}>
        <div className="flex items-center gap-3">
          <h1 className="text-sm font-semibold tracking-tight" style={{ color: 'var(--color-text-primary)' }}>
            模板库
          </h1>
          <span className="text-[10px] rounded-md px-2 py-0.5 font-medium" style={{ background: 'var(--color-accent-muted)', color: 'var(--color-accent)' }}>
            {templates.length} 个模板
          </span>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="sm" onClick={() => setCategoryModalOpen(true)} title="管理分类">
            <FolderPlus size={15} />
          </Button>
          <Button size="sm" onClick={handleNewTemplate}>
            <Plus size={15} />
            新建模板
          </Button>
        </div>
      </div>

      {/* 搜索栏 + 分类筛选 */}
      <div className="flex shrink-0 items-center gap-2 border-b px-5 py-2.5" style={{ borderColor: 'var(--color-border-subtle)' }}>
        <div
          className="flex flex-1 items-center gap-2 rounded-lg border px-3 py-1.5 transition-colors duration-200 focus-within:border-[var(--color-accent)]"
          style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}
        >
          <Search size={14} style={{ color: 'var(--color-text-muted)' }} />
          <input
            type="text" placeholder="搜索模板..."
            className="flex-1 bg-transparent text-xs outline-none"
            style={{ color: 'var(--color-text-primary)' }}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          {searchQuery && (
            <button onClick={() => setSearchQuery('')} className="rounded p-0.5 hover:bg-[var(--color-surface-secondary)]">
              <X size={12} style={{ color: 'var(--color-text-muted)' }} />
            </button>
          )}
        </div>
      </div>

      {/* 分类标签 */}
      {categories.length > 0 && (
        <div className="flex shrink-0 items-center gap-1.5 overflow-x-auto border-b px-5 py-2" style={{ borderColor: 'var(--color-border-subtle)' }}>
          <button
            onClick={() => setSelectedCategory(null)}
            className="shrink-0 rounded-md px-2.5 py-1 text-[11px] font-medium transition-all duration-150"
            style={{
              background: !selectedCategoryId ? 'var(--color-accent)' : 'var(--color-surface-secondary)',
              color: !selectedCategoryId ? '#fff' : 'var(--color-text-secondary)',
            }}
          >
            全部
          </button>
          {categories.map((cat) => (
            <div key={cat.id} className="group/cat relative shrink-0">
              {editingCategoryId === cat.id ? (
                <input
                  value={editingCategoryName}
                  onChange={(e) => setEditingCategoryName(e.target.value)}
                  onBlur={() => handleSaveRename(cat.id)}
                  onKeyDown={(e) => { if (e.key === 'Enter') handleSaveRename(cat.id); if (e.key === 'Escape') setEditingCategoryId(null); }}
                  className="w-24 rounded-md border px-2 py-1 text-[11px] outline-none"
                  style={{ background: 'var(--color-surface)', borderColor: 'var(--color-accent)', color: 'var(--color-text-primary)' }}
                  autoFocus
                />
              ) : (
                <button
                  onClick={() => setSelectedCategory(selectedCategoryId === cat.id ? null : cat.id)}
                  onDoubleClick={() => handleStartRename(cat.id, cat.name)}
                  className="rounded-md px-2.5 py-1 text-[11px] font-medium transition-all duration-150"
                  style={{
                    background: selectedCategoryId === cat.id ? 'var(--color-accent)' : 'var(--color-surface-secondary)',
                    color: selectedCategoryId === cat.id ? '#fff' : 'var(--color-text-secondary)',
                  }}
                  title="双击重命名"
                >
                  {cat.name}
                </button>
              )}
              <button
                onClick={() => deleteCategory(cat.id)}
                className="absolute -right-1 -top-1 hidden rounded-full p-0.5 group-hover/cat:flex"
                style={{ background: 'var(--color-danger)', color: '#fff' }}
              >
                <X size={8} />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* 模板网格 */}
      <div className="flex-1 overflow-y-auto p-5">
        {filteredTemplates.length > 0 ? (
          <div className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
            {filteredTemplates.map((t) => (
              <TemplateCard key={t.id} template={t} onEdit={handleEditTemplate} />
            ))}
          </div>
        ) : (
          <div className="flex h-full flex-col items-center justify-center rounded-xl border border-dashed" style={{ borderColor: 'var(--color-border)' }}>
            <div className="text-center">
              <p className="mb-1 text-sm font-medium" style={{ color: 'var(--color-text-secondary)' }}>
                {templates.length === 0 ? '模板库为空' : '没有匹配的模板'}
              </p>
              <p className="mb-4 text-xs" style={{ color: 'var(--color-text-muted)' }}>
                {templates.length === 0 ? '创建模板来快速填充每日任务' : '试试其他关键词或分类'}
              </p>
              <Button size="sm" onClick={handleNewTemplate}>
                <Plus size={15} />创建模板
              </Button>
            </div>
          </div>
        )}
      </div>

      <TemplateFormModal open={formOpen} onClose={handleFormClose} editingTemplate={editingTemplate} />

      <Modal open={categoryModalOpen} onClose={() => setCategoryModalOpen(false)} title="管理分类" width="sm">
        <div className="flex flex-col gap-4">
          <div className="flex items-center gap-2">
            <input
              type="text" value={newCategoryName}
              onChange={(e) => setNewCategoryName(e.target.value)}
              placeholder="分类名称..."
              className="flex-1 rounded-lg border px-3 py-2 text-sm outline-none focus:border-[var(--color-accent)]"
              style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)', color: 'var(--color-text-primary)' }}
              onKeyDown={(e) => { if (e.key === 'Enter') handleAddCategory(); }}
            />
            <Button size="sm" onClick={handleAddCategory} disabled={!newCategoryName.trim()}>添加</Button>
          </div>
          {categories.length > 0 && (
            <div className="flex flex-col gap-1">
              <p className="text-[10px] font-medium" style={{ color: 'var(--color-text-muted)' }}>
                已有分类（{categories.length} 个）
              </p>
              {categories.map((cat) => (
                <div key={cat.id} className="flex items-center justify-between rounded-lg px-3 py-2" style={{ background: 'var(--color-surface-secondary)' }}>
                  <span className="text-xs font-medium" style={{ color: 'var(--color-text-primary)' }}>{cat.name}</span>
                  <button onClick={() => deleteCategory(cat.id)} className="rounded p-1 hover:bg-[var(--color-danger-muted)] transition-colors">
                    <X size={14} style={{ color: 'var(--color-text-muted)' }} />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </Modal>
    </div>
  );
}
