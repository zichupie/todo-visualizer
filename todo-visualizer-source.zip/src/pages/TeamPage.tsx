import { useState } from 'react';
import { useTeamStore, DEFAULT_MEMBERS } from '@/stores/useTeamStore';
import { useTaskStore } from '@/stores/useTaskStore';
import { useSettingStore } from '@/stores/useSettingStore';
import { useScheduleStore } from '@/stores/useScheduleStore';
import { formatDate, getWeekDates, formatDateDisplay } from '@/utils/date';
import { formatDurationShort, calculateUsagePercent } from '@/utils/duration';
import { ChevronLeft, ChevronRight, Clock } from 'lucide-react';
import clsx from 'clsx';

export function TeamPage() {
  const { members } = useTeamStore();
  const { settings } = useSettingStore();
  const [weekOffset, setWeekOffset] = useState(0);

  const baseDate = new Date();
  baseDate.setDate(baseDate.getDate() + weekOffset * 7);
  const weekDates = getWeekDates(baseDate);
  const today = formatDate(new Date());
  const [selectedDate, setSelectedDate] = useState(today);
  const displayDate = weekDates[0] + ' ~ ' + weekDates[6];

  return (
    <div className="flex h-full flex-col overflow-y-auto">
      {/* 标题 + 日期导航 */}
      <div className="flex shrink-0 items-center justify-between border-b px-5 py-3" style={{ borderColor: 'var(--color-border-subtle)' }}>
        <h1 className="text-sm font-semibold" style={{ color: 'var(--color-text-primary)' }}>团队总览</h1>
        <div className="flex items-center gap-2">
          <button onClick={() => setWeekOffset((o) => o - 1)} className="rounded-md p-1 hover:bg-[var(--color-surface-secondary)]">
            <ChevronLeft size={14} style={{ color: 'var(--color-text-muted)' }} />
          </button>
          <span className="text-[11px] font-medium" style={{ color: 'var(--color-text-secondary)' }}>{displayDate}</span>
          <button onClick={() => setWeekOffset((o) => Math.min(0, o + 1))} disabled={weekOffset >= 0}
            className="rounded-md p-1 hover:bg-[var(--color-surface-secondary)]" style={{ opacity: weekOffset >= 0 ? 0.3 : 1 }}>
            <ChevronRight size={14} style={{ color: 'var(--color-text-muted)' }} />
          </button>
        </div>
      </div>

      {/* 日期选择标签 */}
      <div className="flex shrink-0 gap-1 overflow-x-auto border-b px-5 py-2" style={{ borderColor: 'var(--color-border-subtle)' }}>
        {weekDates.map((date) => (
          <button key={date} onClick={() => setSelectedDate(date)}
            className={clsx('shrink-0 rounded-lg px-3 py-1.5 text-[11px] font-medium transition-all',
              selectedDate === date ? 'bg-[var(--color-accent)] text-white' : date === today ? 'bg-[var(--color-accent-muted)] text-[var(--color-accent)]' : '')}
            style={selectedDate !== date && date !== today ? { background: 'var(--color-surface-secondary)', color: 'var(--color-text-secondary)' } : undefined}>
            {formatDateDisplay(date).weekday}<br/><span className="text-[10px]">{formatDateDisplay(date).date}</span>
          </button>
        ))}
      </div>

      {/* 全部汇总卡片 */}
      <div className="shrink-0 px-5 py-4">
        <AllSummary date={selectedDate} />
      </div>

      {/* 分隔 */}
      <div className="flex items-center gap-2 px-5 py-1.5 border-b" style={{ borderColor: 'var(--color-border-subtle)' }}>
        <span className="text-[10px] font-semibold" style={{ color: 'var(--color-text-muted)' }}>成员明细</span>
      </div>

      {/* 成员卡片列表 */}
      <div className="flex-1 space-y-3 overflow-y-auto p-5">
        {members.map((member) => (
          <MemberCard key={member.id} member={member} date={selectedDate} />
        ))}
      </div>
    </div>
  );
}

/* ===== 全部汇总卡片 ===== */
function AllSummary({ date }: { date: string }) {
  const { tasks: allTasks } = useTaskStore();
  const { members } = useTeamStore();
  const { settings } = useSettingStore();
  const { getOrCreateSchedule } = useScheduleStore();

  const schedule = getOrCreateSchedule(date);
  const capacity = schedule.capacity;

  // 所有成员的任务
  const memberData = members.map((m) => {
    const tasks = allTasks.filter((t) => t.date === date && t.personId === m.id);
    const total = tasks.reduce((s, t) => s + t.duration, 0);
    return { ...m, tasks, total, pct: calculateUsagePercent(total, capacity) };
  });

  const totalUsed = memberData.reduce((s, m) => s + m.total, 0);
  const totalCapacity = capacity * members.length;
  const overallPct = Math.round((totalUsed / totalCapacity) * 100);

  // 合并任务分布
  const allDayTasks = allTasks.filter((t) => t.date === date);
  const todoCount = allDayTasks.filter((t) => t.status === 'todo').length;
  const progressCount = allDayTasks.filter((t) => t.status === 'in-progress').length;
  const reviewCount = allDayTasks.filter((t) => t.status === 'review').length;
  const doneCount = allDayTasks.filter((t) => t.status === 'done').length;
  const totalCount = allDayTasks.length;
  const barTotal = Math.max(totalUsed, totalCapacity);

  return (
    <div className="rounded-xl border p-4" style={{ borderColor: 'var(--color-border)', background: 'var(--color-surface)' }}>
      <div className="mb-3 flex items-center justify-between">
        <span className="text-xs font-semibold" style={{ color: 'var(--color-text-primary)' }}>全部团队</span>
        <span className="text-[10px] rounded px-2 py-0.5" style={{ background: 'var(--color-accent-muted)', color: 'var(--color-accent)' }}>{formatDateDisplay(date).weekday} {formatDateDisplay(date).date}</span>
      </div>

      {/* 大数字 */}
      <div className="mb-4 grid grid-cols-3 gap-3">
        <div className="rounded-lg p-3 text-center" style={{ background: 'var(--color-surface-secondary)' }}>
          <p className="text-xl font-bold" style={{ color: overallPct > 100 ? 'var(--color-danger)' : 'var(--color-text-primary)' }}>{formatDurationShort(totalUsed)}</p>
          <p className="text-[9px] font-medium" style={{ color: 'var(--color-text-muted)' }}>总已用 / {formatDurationShort(totalCapacity)}</p>
        </div>
        <div className="rounded-lg p-3 text-center" style={{ background: 'var(--color-surface-secondary)' }}>
          <p className={clsx('text-xl font-bold', overallPct > 100 ? 'text-[var(--color-danger)]' : overallPct > 80 ? 'text-[var(--color-warning)]' : 'text-[var(--color-success)]')}>{overallPct}%</p>
          <p className="text-[9px] font-medium" style={{ color: 'var(--color-text-muted)' }}>整体饱和度</p>
        </div>
        <div className="rounded-lg p-3 text-center" style={{ background: 'var(--color-surface-secondary)' }}>
          <p className="text-xl font-bold" style={{ color: 'var(--color-text-primary)' }}>{totalCount}</p>
          <p className="text-[9px] font-medium" style={{ color: 'var(--color-text-muted)' }}>总任务数</p>
        </div>
      </div>

      {/* 任务分布条 */}
      {totalCount > 0 && (
        <div className="mb-2">
          <div className="flex h-5 overflow-hidden rounded-md" style={{ background: 'var(--color-surface-secondary)' }}>
            {todoCount > 0 && (<div className="flex items-center justify-center text-[8px] font-medium text-white" style={{ width: `${Math.round(todoCount/totalCount*100)}%`, background: '#94a3b8', minWidth: '12px' }}>{todoCount > 1 ? todoCount : ''}</div>)}
            {progressCount > 0 && (<div className="flex items-center justify-center text-[8px] font-medium text-white" style={{ width: `${Math.round(progressCount/totalCount*100)}%`, background: '#6366f1', minWidth: '12px' }}>{progressCount > 1 ? progressCount : ''}</div>)}
            {reviewCount > 0 && (<div className="flex items-center justify-center text-[8px] font-medium text-white" style={{ width: `${Math.round(reviewCount/totalCount*100)}%`, background: '#f59e0b', minWidth: '12px' }}>{reviewCount > 1 ? reviewCount : ''}</div>)}
            {doneCount > 0 && (<div className="flex items-center justify-center text-[8px] font-medium text-white" style={{ width: `${Math.round(doneCount/totalCount*100)}%`, background: '#22c55e', minWidth: '12px' }}>{doneCount > 1 ? doneCount : ''}</div>)}
          </div>
          <div className="mt-1.5 flex flex-wrap gap-x-3 text-[9px]" style={{ color: 'var(--color-text-muted)' }}>
            {todoCount > 0 && <><span className="inline-block h-2 w-2 rounded-full" style={{ background: '#94a3b8' }} />{todoCount} 待办</>}
            {progressCount > 0 && <><span className="inline-block h-2 w-2 rounded-full" style={{ background: '#6366f1' }} />{progressCount} 进行中</>}
            {reviewCount > 0 && <><span className="inline-block h-2 w-2 rounded-full" style={{ background: '#f59e0b' }} />{reviewCount} 待审核</>}
            {doneCount > 0 && <><span className="inline-block h-2 w-2 rounded-full" style={{ background: '#22c55e' }} />{doneCount} 已完成</>}
          </div>
        </div>
      )}

      {/* 成员饱和度条 */}
      <div className="flex gap-1.5 mt-2">
        {memberData.map((m) => (
          <div key={m.id} className="flex-1 rounded-md p-2 text-center" style={{ background: m.color + '10' }}>
            <p className="text-[10px] font-semibold" style={{ color: m.color }}>{m.name}</p>
            <p className="text-[9px] font-bold" style={{ color: m.pct > 100 ? 'var(--color-danger)' : 'var(--color-text-primary)' }}>
              {m.pct > 0 ? `${m.pct}%` : '–'}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ===== 成员明细卡片 ===== */
function MemberCard({ member, date }: { member: typeof DEFAULT_MEMBERS[0]; date: string }) {
  const { tasks: allTasks } = useTaskStore();
  const { settings } = useSettingStore();
  const { getOrCreateSchedule } = useScheduleStore();

  const schedule = getOrCreateSchedule(date);
  const tasks = allTasks.filter((t) => t.date === date && t.personId === member.id).sort((a, b) => a.order - b.order);
  const totalUsed = tasks.reduce((sum, t) => sum + t.duration, 0);
  const capacity = schedule.capacity;
  const usagePercent = calculateUsagePercent(totalUsed, capacity);

  return (
    <div className="rounded-xl border p-4" style={{ borderColor: 'var(--color-border)', background: 'var(--color-surface)' }}>
      <div className="flex items-center gap-3 mb-3">
        <div className="flex h-8 w-8 items-center justify-center rounded-full text-xs font-bold" style={{ background: member.color, color: '#fff' }}>{member.name[0]}</div>
        <div className="flex-1">
          <p className="text-xs font-semibold" style={{ color: 'var(--color-text-primary)' }}>{member.name}</p>
          <p className="text-[10px]" style={{ color: 'var(--color-text-muted)' }}>{tasks.length} 个任务 · 已用 {formatDurationShort(totalUsed)} / {formatDurationShort(capacity)}</p>
        </div>
        <div className="text-right">
          <p className={clsx('text-sm font-bold', usagePercent > 100 ? 'text-[var(--color-danger)]' : usagePercent > 80 ? 'text-[var(--color-warning)]' : 'text-[var(--color-success)]')}>{usagePercent}%</p>
        </div>
      </div>

      {tasks.length > 0 ? (
        <div className="space-y-1">
          {tasks.map((task) => (
            <div key={task.id} className="flex items-center gap-2 rounded px-2 py-1 text-[10px]" style={{ background: task.color + '25', borderLeft: `2px solid ${task.color}` }}>
              <span className="flex-1 truncate font-medium" style={{ color: 'var(--color-text-primary)' }}>{task.name}</span>
              <span className="shrink-0 rounded px-1 py-0.5 text-[9px]" style={{ background: 'var(--color-surface-secondary)', color: 'var(--color-text-muted)' }}>{formatDurationShort(task.duration)}</span>
            </div>
          ))}
        </div>
      ) : (
        <p className="py-3 text-center text-[10px]" style={{ color: 'var(--color-text-muted)' }}>
          <Clock size={14} className="inline mr-1 opacity-30" />当日无任务
        </p>
      )}
    </div>
  );
}
