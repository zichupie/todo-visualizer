import { useState, useRef } from 'react';
import { Button } from '@/components/ui/Button';
import { useSettingStore } from '@/stores/useSettingStore';
import { useToastStore } from '@/stores/useToastStore';
import { exportAllData, importAllData } from '@/services/dataDir';
import { FolderOpen, Download, Upload, Trash2, Clock, ShieldAlert } from 'lucide-react';

export function SettingsPage() {
  const { settings, setDefaultCapacity, setPxPerHour, updateSettings } = useSettingStore();
  const showToast = useToastStore((s) => s.show);
  const [showClear, setShowClear] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const handleExport = () => {
    const json = exportAllData();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const ts = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    a.href = url;
    a.download = `work-capacity-backup-${ts}.json`;
    a.click();
    URL.revokeObjectURL(url);
    updateSettings({ lastBackupAt: new Date().toISOString() });
    showToast('备份已导出', 'success');
  };

  const handleImport = () => {
    fileRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const ok = importAllData(reader.result as string, 'overwrite');
      if (ok) {
        showToast('数据已导入，请刷新页面', 'success');
        setTimeout(() => window.location.reload(), 1500);
      } else {
        showToast('导入失败，文件格式错误', 'error');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleClear = () => {
    const keys = Object.keys(localStorage).filter((k) => k.startsWith('wce_'));
    keys.forEach((k) => localStorage.removeItem(k));
    showToast('数据已清除，请刷新页面', 'info');
    setShowClear(false);
    setTimeout(() => window.location.reload(), 1000);
  };

  return (
    <div className="flex h-full flex-col overflow-y-auto p-4">
      <h1 className="mb-6 text-lg font-semibold tracking-tight" style={{ color: 'var(--color-text-primary)' }}>
        设置
      </h1>

      <div className="flex max-w-lg flex-col gap-6 pb-10">
        {/* 每日默认容量 */}
        <div
          className="rounded-xl border p-4"
          style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}
        >
          <label className="mb-3 block text-sm font-medium" style={{ color: 'var(--color-text-primary)' }}>
            每日默认容量（小时）
          </label>
          <div className="flex items-center gap-3">
            <input
              type="number" min={0.5} max={24} step={0.5}
              value={settings.defaultCapacity / 60}
              onChange={(e) => {
                const hours = Math.max(0.5, Math.min(24, parseFloat(e.target.value) || 8));
                setDefaultCapacity(Math.round(hours * 60));
              }}
              className="w-20 rounded-lg border px-3 py-2 text-sm text-center outline-none focus:border-[var(--color-accent)]"
              style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)', color: 'var(--color-text-primary)' }}
            />
            <span className="text-sm" style={{ color: 'var(--color-text-secondary)' }}>
              小时/天（{settings.defaultCapacity} 分钟）
            </span>
          </div>
        </div>

        {/* 高度比例 */}
        <div
          className="rounded-xl border p-4"
          style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}
        >
          <label className="mb-3 block text-sm font-medium" style={{ color: 'var(--color-text-primary)' }}>
            高度比例（px/小时）
          </label>
          <div className="flex items-center gap-3">
            <input
              type="number" min={10} max={200}
              value={settings.pxPerHour}
              onChange={(e) => setPxPerHour(Math.max(10, parseInt(e.target.value) || 50))}
              className="w-20 rounded-lg border px-3 py-2 text-sm text-center outline-none focus:border-[var(--color-accent)]"
              style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)', color: 'var(--color-text-primary)' }}
            />
            <span className="text-sm" style={{ color: 'var(--color-text-secondary)' }}>
              px（最小 10px）
            </span>
          </div>
        </div>

        {/* 备份设置 */}
        <div
          className="rounded-xl border p-4"
          style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}
        >
          <h3 className="mb-3 flex items-center gap-2 text-sm font-medium" style={{ color: 'var(--color-text-primary)' }}>
            <FolderOpen size={16} style={{ color: 'var(--color-accent)' }} />
            备份设置
          </h3>

          {/* 备份路径 */}
          <div className="mb-4">
            <label className="mb-1.5 block text-xs font-medium" style={{ color: 'var(--color-text-secondary)' }}>
              本地备份路径
            </label>
            <input
              type="text"
              value={settings.backupDir}
              onChange={(e) => updateSettings({ backupDir: e.target.value })}
              placeholder="例如：D:\备份\work-capacity\"
              className="w-full rounded-lg border px-3 py-2 text-sm outline-none focus:border-[var(--color-accent)]"
              style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)', color: 'var(--color-text-primary)' }}
            />
            <p className="mt-1 text-[11px]" style={{ color: 'var(--color-text-muted)' }}>
              仅作为参考记录，浏览器无法直接写入磁盘路径。点击下方按钮手动导出备份。
            </p>
          </div>

          {/* 自动备份提醒 */}
          <div className="mb-4 flex items-center justify-between">
            <span className="text-xs" style={{ color: 'var(--color-text-secondary)' }}>
              每周备份提醒
            </span>
            <button
              onClick={() => updateSettings({ autoBackup: !settings.autoBackup })}
              className="relative h-6 w-11 rounded-full transition-colors duration-200"
              style={{
                background: settings.autoBackup ? 'var(--color-accent)' : 'var(--color-border)',
              }}
            >
              <span
                className="absolute top-0.5 h-5 w-5 rounded-full bg-white shadow-sm transition-all duration-200"
                style={{ left: settings.autoBackup ? 'calc(100% - 22px)' : '2px' }}
              />
            </button>
          </div>

          {/* 上次备份时间 */}
          {settings.lastBackupAt && (
            <div className="mb-3 flex items-center gap-1.5 text-xs" style={{ color: 'var(--color-text-muted)' }}>
              <Clock size={12} />
              上次备份：{new Date(settings.lastBackupAt).toLocaleString('zh-CN')}
            </div>
          )}
        </div>

        {/* 数据管理 */}
        <div
          className="rounded-xl border p-4"
          style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}
        >
          <h3 className="mb-3 text-sm font-medium" style={{ color: 'var(--color-text-primary)' }}>
            数据管理
          </h3>
          <div className="flex flex-wrap gap-2">
            <Button variant="secondary" size="sm" onClick={handleExport}>
              <Download size={14} className="mr-1" />
              导出备份
            </Button>
            <Button variant="secondary" size="sm" onClick={handleImport}>
              <Upload size={14} className="mr-1" />
              导入备份
            </Button>
            <input ref={fileRef} type="file" accept=".json" className="hidden" onChange={handleFileChange} />
            {showClear ? (
              <div className="flex items-center gap-2">
                <Button variant="secondary" size="sm" onClick={handleClear} style={{ background: 'var(--color-danger-muted)', color: 'var(--color-danger)' }}>
                  <ShieldAlert size={14} className="mr-1" />
                  确认清除
                </Button>
                <Button variant="ghost" size="sm" onClick={() => setShowClear(false)}>
                  取消
                </Button>
              </div>
            ) : (
              <Button variant="ghost" size="sm" onClick={() => setShowClear(true)}>
                <Trash2 size={14} className="mr-1" />
                清除数据
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
