import React, { useState, useCallback, useMemo } from 'react';
import {
  DndContext,
  DragOverlay,
  PointerSensor,
  TouchSensor,
  useSensor,
  useSensors,
  useDroppable,
  useDraggable,
  closestCorners,
} from '@dnd-kit/core';
import { restrictToWindowEdges } from '@dnd-kit/modifiers';
import {
  ChevronLeft,
  ChevronRight,
  PanelLeftClose,
  PanelLeft,
  Plus,
  Trash2,
} from 'lucide-react';
import clsx from 'clsx';
import { getWeekDates, formatDateDisplay, isToday } from '@/utils/date';
import { formatDurationShort, durationToPx, calculateUsagePercent, getUsageColor } from '@/utils/duration';
import { useTaskStore } from '@/stores/useTaskStore';
import { useTemplateStore } from '@/stores/useTemplateStore';
import { useQuickTaskStore } from '@/stores/useQuickTaskStore';
import { useSettingStore } from '@/stores/useSettingStore';
import { useScheduleStore } from '@/stores/useScheduleStore';
import { useTeamStore } from '@/stores/useTeamStore';
import { TemplateIcon } from '@/components/template/TemplateIcon';
import { Button } from '@/components/ui/Button';
import { TaskCard } from '@/components/capacity/TaskCard';
import { TiltWrapper } from '@/components/effects/TiltWrapper';
import { PRESET_COLORS } from '@/types';
import type { Template, Task } from '@/types';

/* ===== 模板面板 ===== */
function DraggableTemplate({ template }: { template: Template }) {
  const handleDragStartHtml = (e: React.DragEvent) => {
    e.dataTransfer.setData('text/plain', JSON.stringify({ type: 'template', template }));
    e.dataTransfer.effectAllowed = 'copy';
  };

  return (
    <div
      draggable
      onDragStart={handleDragStartHtml}
      className="flex cursor-grab items-center gap-2 rounded-lg border p-2.5 transition-all duration-150 active:cursor-grabbing active:scale-[0.97] hover:shadow-sm"
      style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}
    >
      <div
        className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md"
        style={{ background: template.color + '1a', color: template.color }}
      >
        <TemplateIcon name={template.iconValue} size={13} />
      </div>
      <div className="min-w-0 flex-1">
        <p className="truncate text-[11px] font-medium leading-tight" style={{ color: 'var(--color-text-primary)' }}>
          {template.name}
        </p>
        <p className="text-[9px]" style={{ color: 'var(--color-text-muted)' }}>
          {formatDurationShort(template.defaultDuration)}
        </p>
      </div>
    </div>
  );
}

/* ===== 模板拖拽面板 (含快速任务创建) ===== */
function TemplatePanel({ open, onToggle, weekStart }: { open: boolean; onToggle: () => void; weekStart: string }) {
  const { templates } = useTemplateStore();
  const { addTask: addQuickTask } = useQuickTaskStore();
  // 全局临时任务（不限周）
  const quickTasks = useQuickTaskStore((s) => s.tasks);

  const [showQuickForm, setShowQuickForm] = useState(false);
  const [quickName, setQuickName] = useState('');
  const [quickColor, setQuickColor] = useState(PRESET_COLORS[0]);
  const [quickDuration, setQuickDuration] = useState(1);

  const handleQuickCreate = () => {
    if (!quickName.trim()) return;
    addQuickTask({
      name: quickName.trim(),
      iconValue: 'zap',
      color: quickColor,
      duration: quickDuration * 60,
    });
    setQuickName('');
    setQuickDuration(1);
    setShowQuickForm(false);
  };

  return (
    <div
      className={clsx(
        'relative flex flex-col border-r transition-all duration-300 ease-premium',
        open ? 'w-52' : 'w-0'
      )}
      style={{ borderColor: 'var(--color-border)', overflow: 'hidden' }}
    >
      <div className="flex w-52 shrink-0 flex-col overflow-y-auto" style={{ minWidth: '13rem' }}>
        {/* ===== 面板标题栏 ===== */}
        <div
          className="flex items-center justify-between border-b px-3 py-2.5"
          style={{ borderColor: 'var(--color-border-subtle)' }}
        >
          <span className="text-[11px] font-semibold tracking-tight" style={{ color: 'var(--color-text-primary)' }}>
            任务面板
          </span>
          <div className="flex items-center gap-1">
            <button
              onClick={() => setShowQuickForm(!showQuickForm)}
              className="rounded-md p-1 hover:bg-[var(--color-surface-secondary)] transition-colors"
              title="快速创建"
            >
              <Plus size={14} style={{ color: 'var(--color-text-muted)' }} />
            </button>
            <button
              onClick={onToggle}
              className="rounded-md p-1 hover:bg-[var(--color-surface-secondary)] transition-colors"
              title="收起面板"
            >
              <PanelLeftClose size={14} style={{ color: 'var(--color-text-muted)' }} />
            </button>
          </div>
        </div>

        {/* ===== 快速创建表单 ===== */}
        {showQuickForm && (
          <div className="flex flex-col gap-2 border-b p-2" style={{ borderColor: 'var(--color-border-subtle)' }}>
            <input
              type="text"
              value={quickName}
              onChange={(e) => setQuickName(e.target.value)}
              placeholder="任务名称..."
              className="w-full rounded-md border px-2 py-1.5 text-[11px] outline-none focus:border-[var(--color-accent)]"
              style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)', color: 'var(--color-text-primary)' }}
              onKeyDown={(e) => { if (e.key === 'Enter') handleQuickCreate(); }}
              autoFocus
            />
            <div className="flex items-end gap-2">
              <div className="flex-1">
                <label className="mb-0.5 block text-[9px]" style={{ color: 'var(--color-text-muted)' }}>时长(h)</label>
                <input
                  type="number" min={0.5} max={24} step={0.5}
                  value={quickDuration}
                  onChange={(e) => setQuickDuration(parseFloat(e.target.value) || 1)}
                  className="w-full rounded-md border px-2 py-1 text-[11px] text-center outline-none"
                  style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)', color: 'var(--color-text-primary)' }}
                />
              </div>
              <Button size="sm" onClick={handleQuickCreate} disabled={!quickName.trim()}>添加</Button>
              <Button variant="ghost" size="sm" onClick={() => setShowQuickForm(false)}>取消</Button>
            </div>
            {/* 颜色选择 */}
            <div className="flex flex-wrap gap-1.5">
              {PRESET_COLORS.slice(0, 8).map((c) => (
                <button
                  key={c}
                  onClick={() => setQuickColor(c)}
                  className="h-4 w-4 rounded-full border-2 transition-all"
                  style={{
                    background: c,
                    borderColor: quickColor === c ? 'var(--color-text-primary)' : 'transparent',
                    transform: quickColor === c ? 'scale(1.2)' : 'scale(1)',
                  }}
                />
              ))}
            </div>
          </div>
        )}

        {/* ===== 本周快速任务 ===== */}
        {quickTasks.length > 0 && (
          <>
            <div className="flex items-center gap-1.5 px-3 py-2 border-b" style={{ borderColor: 'var(--color-border-subtle)' }}>
              <span className="text-[9px] font-semibold" style={{ color: 'var(--color-text-muted)' }}>快速任务</span>
              <span className="text-[8px] rounded px-1 py-0.5" style={{ background: 'var(--color-surface-secondary)', color: 'var(--color-text-muted)' }}>
                {quickTasks.length}
              </span>
            </div>
            <div className="space-y-1 p-2 border-b" style={{ borderColor: 'var(--color-border-subtle)' }}>
              {quickTasks.map((qt) => (
                <DraggableQuickTask key={qt.id} task={qt} />
              ))}
            </div>
          </>
        )}

        {/* ===== 模板列表标题 ===== */}
        <div className="flex items-center gap-1.5 px-3 py-2 border-b" style={{ borderColor: 'var(--color-border-subtle)' }}>
          <span className="text-[9px] font-semibold" style={{ color: 'var(--color-text-muted)' }}>模板库</span>
          <span className="text-[8px] rounded px-1 py-0.5" style={{ background: 'var(--color-surface-secondary)', color: 'var(--color-text-muted)' }}>
            {templates.length}
          </span>
        </div>

        {/* 模板列表 */}
        <div className="flex-1 space-y-1.5 overflow-y-auto p-2">
          {templates.length === 0 ? (
            <p className="py-4 text-center text-[10px]" style={{ color: 'var(--color-text-muted)' }}>
              暂无模板，请先到模板库创建
            </p>
          ) : (
            templates.map((t) => <DraggableTemplate key={t.id} template={t} />)
          )}
        </div>
      </div>
    </div>
  );
}

/* ===== 可拖拽快速任务 ===== */
function DraggableQuickTask({ task }: { task: { id: string; name: string; color: string; duration: number } }) {
  const handleDragStartHtml = (e: React.DragEvent) => {
    e.dataTransfer.setData('text/plain', JSON.stringify({
      type: 'template',
      template: {
        id: task.id, name: task.name,
        iconType: 'lucide', iconValue: 'zap',
        color: task.color, defaultDuration: task.duration,
        defaultStatus: 'todo', categoryId: null,
      },
    }));
    e.dataTransfer.effectAllowed = 'copy';
  };

  return (
    <div
      draggable
      onDragStart={handleDragStartHtml}
      className="flex cursor-grab items-center gap-2 rounded-lg border p-2 transition-all duration-150 active:cursor-grabbing active:scale-[0.97] hover:shadow-sm"
      style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}
    >
      <div
        className="flex h-6 w-6 shrink-0 items-center justify-center rounded"
        style={{ background: task.color + '1a', color: task.color }}
      >
        <Plus size={11} />
      </div>
      <div className="min-w-0 flex-1">
        <p className="truncate text-[10px] font-medium leading-tight" style={{ color: 'var(--color-text-primary)' }}>
          {task.name}
        </p>
        <p className="text-[8px]" style={{ color: 'var(--color-text-muted)' }}>
          {formatDurationShort(task.duration)}
        </p>
      </div>
      <button
        type="button"
        className="ml-1 flex h-5 w-5 shrink-0 cursor-pointer items-center justify-center rounded border text-[10px] font-bold leading-none transition-colors hover:border-red-500 hover:bg-red-500 hover:text-white"
        style={{ color: '#ef4444', borderColor: 'rgba(239,68,68,0.4)', background: 'rgba(239,68,68,0.08)' }}
        onClick={(e) => {
          e.preventDefault();
          e.stopPropagation();
          const { tasks: allTasks, deleteTask } = useTaskStore.getState();
          allTasks.filter((t) => t.templateId === task.id).forEach((t) => deleteTask(t.id));
          useQuickTaskStore.getState().deleteTask(task.id);
        }}
        title="删除快速任务及所有关联卡片"
      >
        ✕
      </button>
    </div>
  );
}

/* ===== 任务卡片（可拖放）===== */
const DroppableTaskWrapper = React.memo(function DroppableTaskWrapper({
  task,
  idx,
  tasks,
  onMoveUp,
  onMoveDown,
}: {
  task: Task;
  idx: number;
  tasks: Task[];
  onMoveUp: (id: string) => void;
  onMoveDown: (id: string) => void;
}) {
  const { setNodeRef, isOver } = useDroppable({
    id: `slot-${task.id}`,
    data: { type: 'task', task },
  });

  const isOverflow = false; // placeholder
  const taskStartsOverflow = false;

  return (
    <div
      ref={setNodeRef}
      className={clsx(
        'group/task relative rounded-lg transition-all duration-150',
        isOver && 'ring-2 ring-[var(--color-accent)]'
      )}
    >
      <TiltWrapper rotateAmplitude={6} scaleOnHover={1.02} className="w-full">
        <TaskCard task={task} isOverCapacity={false} />
      </TiltWrapper>
      {/* 拖入高亮指示 */}
      {isOver && (
        <div
          className="pointer-events-none absolute inset-0 flex items-center justify-center rounded-lg"
          style={{ background: 'var(--color-accent-muted)', opacity: 0.5 }}
        >
          <span className="text-[10px] font-semibold" style={{ color: 'var(--color-accent)' }}>
            放置至此
          </span>
        </div>
      )}
      {/* 排序按钮 */}
      <div className="absolute -right-1 top-1/2 -translate-y-1/2 flex flex-col gap-0.5 opacity-0 group-hover/task:opacity-100 transition-opacity z-30">
        <button
          onClick={(e) => { e.stopPropagation(); onMoveUp(task.id); }}
          className="rounded p-0.5 hover:bg-[var(--color-surface-secondary)]"
          disabled={idx === 0}
        >
          <ChevronLeft size={10} className="rotate-90" style={{ color: 'var(--color-text-muted)' }} />
        </button>
        <button
          onClick={(e) => { e.stopPropagation(); onMoveDown(task.id); }}
          className="rounded p-0.5 hover:bg-[var(--color-surface-secondary)]"
          disabled={idx === tasks.length - 1}
        >
          <ChevronRight size={10} className="rotate-90" style={{ color: 'var(--color-text-muted)' }} />
        </button>
      </div>
    </div>
  );
});
function MultiMemberColumn({ date }: { date: string }) {
  const { members } = useTeamStore();
  const display = formatDateDisplay(date);
  const today = isToday(date);

  return (
    <div className="flex min-w-[200px] flex-1 flex-col">
      <div className={clsx('relative flex flex-col items-center gap-0.5 rounded-t-xl border border-b-0 px-2 py-2.5', today && 'ring-1')}
        style={{ minHeight: '60px', background: today ? 'var(--color-accent-muted)' : 'var(--color-surface-secondary)', borderColor: today ? 'var(--color-accent)' : 'var(--color-border)' }}>
        <span className={clsx('text-[10px] font-medium', today && 'font-semibold')} style={{ color: today ? 'var(--color-accent)' : 'var(--color-text-muted)' }}>{display.weekday}</span>
        <span className="text-xs font-semibold" style={{ color: 'var(--color-text-primary)' }}>{display.date}</span>
        {today && <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 rounded-full px-1.5 py-0.5 text-[8px] font-semibold" style={{ background: 'var(--color-accent)', color: '#fff' }}>今天</span>}
      </div>
      <div className="flex flex-1 gap-px rounded-b-xl border border-t-0" style={{ borderColor: 'var(--color-border)', background: 'var(--color-border-subtle)' }}>
        {members.map((m) => (
          <MemberSubColumn key={m.id} member={m} date={date} />
        ))}
      </div>
      <MemberTotalBar date={date} />
    </div>
  );
}

function MemberSubColumn({ member, date }: { member: { id: string; name: string; color: string }; date: string }) {
  const { tasks: allTasks } = useTaskStore();
  const { settings } = useSettingStore();
  const { getOrCreateSchedule } = useScheduleStore();
  const schedule = getOrCreateSchedule(date);
  const tasks = allTasks.filter((t) => t.date === date && t.personId === member.id).sort((a, b) => a.order - b.order);
  const totalUsed = tasks.reduce((sum, t) => sum + t.duration, 0);
  const capacity = schedule.capacity;
  const pct = Math.min(100, Math.round((totalUsed / capacity) * 100));
  const displayTotal = Math.max(totalUsed, capacity);
  const columnH = durationToPx(displayTotal, settings.pxPerHour);

  const { setNodeRef, isOver } = useDroppable({
    id: `col-${date}-${member.id}`,
    data: { type: 'column', date, personId: member.id },
  });

  // 从顶部向下累加每个任务的色块
  let cumulativePx = 0;

  return (
    <div ref={setNodeRef} className={clsx('flex flex-1 flex-col', isOver && 'bg-[var(--color-accent-muted)]')}
      style={{ background: 'var(--color-surface)', minHeight: '250px' }}>
      <div className="border-b px-1 py-0.5 text-center text-[8px] font-semibold" style={{ borderColor: 'var(--color-border-subtle)', color: member.color }}>
        {member.name[0]}
      </div>
      <div className="relative flex-1 overflow-hidden" style={{ minHeight: `${Math.max(120, columnH)}px` }}>
        {/* 空背景 */}
        <div className="absolute inset-0" style={{ background: 'var(--color-surface-secondary)' }} />
        {/* 容量线 */}
        <div className="absolute left-0 right-0" style={{ top: `${durationToPx(capacity, settings.pxPerHour)}px`, borderTop: '1px dashed var(--color-border)' }} />
        {/* 任务色块从顶部向下堆叠 */}
        {tasks.map((task) => {
          const h = durationToPx(task.duration, settings.pxPerHour);
          const top = cumulativePx;
          cumulativePx += h;
          return (
            <div
              key={task.id}
              className="absolute left-0 right-0"
              style={{ top: `${top}px`, height: `${Math.max(2, h)}px`, background: task.color + '50', border: `1px solid ${task.color}70`, borderTop: 0 }}
              title={`${task.name} ${formatDurationShort(task.duration)}`}
            />
          );
        })}
        {/* 溢出标记 */}
        {totalUsed > capacity && (
          <div className="absolute left-0 right-0 flex items-center justify-center" style={{ top: `${durationToPx(capacity + 15, settings.pxPerHour)}px` }}>
            <span className="text-[7px] font-bold" style={{ color: 'var(--color-danger)' }}>+{formatDurationShort(totalUsed - capacity)}</span>
          </div>
        )}
        {/* 底部百分比 */}
        <div className="absolute bottom-0.5 left-0 right-0 text-center">
          <span className="text-[7px] font-bold" style={{ color: pct > 100 ? 'var(--color-danger)' : pct > 80 ? 'var(--color-warning)' : 'var(--color-text-muted)' }}>
            {pct}%
          </span>
        </div>
      </div>
    </div>
  );
}

function MemberTotalBar({ date }: { date: string }) {
  const { members } = useTeamStore();
  const { tasks: allTasks } = useTaskStore();
  const memberData = members.map((m) => {
    const tasks = allTasks.filter((t) => t.date === date && t.personId === m.id);
    return { ...m, total: tasks.reduce((s, t) => s + t.duration, 0) };
  });
  const totalUsed = memberData.reduce((s, m) => s + m.total, 0);
  return (
    <div className="mt-1 flex items-center gap-1 rounded-lg border px-2 py-1" style={{ background: 'var(--color-surface-secondary)', borderColor: 'var(--color-border-subtle)' }}>
      <span className="text-[9px] font-medium" style={{ color: 'var(--color-text-secondary)' }}>{formatDurationShort(totalUsed)}</span>
      {memberData.map((m) => (
        <span key={m.id} className="ml-auto text-[8px]" style={{ color: m.color }}>{m.name.slice(0, 1)} {formatDurationShort(m.total)}</span>
      ))}
    </div>
  );
}

function CapacityColumn({ date }: { date: string }) {
  const { getTasksByDate, addTask, updateTask } = useTaskStore();
  const { settings } = useSettingStore();
  const { getOrCreateSchedule } = useScheduleStore();
  const { activeMemberId } = useTeamStore();

  const display = formatDateDisplay(date);
  const today = isToday(date);
  const schedule = getOrCreateSchedule(date);
  let tasks = getTasksByDate(date);
  // 按团队成员过滤
  if (activeMemberId) {
    tasks = tasks.filter((t) => t.personId === activeMemberId);
  }
  const totalUsed = tasks.reduce((sum, t) => sum + t.duration, 0);
  const usagePercent = calculateUsagePercent(totalUsed, schedule.capacity);
  const remaining = schedule.capacity - totalUsed;

  // 按 pxPerHour 计算柱内总高度
  const capacityHeight = durationToPx(schedule.capacity, settings.pxPerHour);

  // 根据时间节点跨度计算最小高度（确保时间线可见）
  const nodeSpanMinutes = (() => {
    if (schedule.timeNodes.length < 2) return schedule.capacity;
    const first = schedule.timeNodes[0].split(':').map(Number);
    const last = schedule.timeNodes[schedule.timeNodes.length - 1].split(':').map(Number);
    return (last[0] * 60 + last[1]) - (first[0] * 60 + first[1]);
  })();
  const columnMinHeight = Math.max(capacityHeight, durationToPx(nodeSpanMinutes, settings.pxPerHour)) + 40;

  const usedHeight = durationToPx(Math.min(totalUsed, schedule.capacity), settings.pxPerHour);
  const overflowHeight = totalUsed > schedule.capacity
    ? durationToPx(totalUsed - schedule.capacity, settings.pxPerHour)
    : 0;

  // 柱体可拖放
  const { setNodeRef, isOver } = useDroppable({
    id: `column-${date}`,
    data: { type: 'column', date },
  });

  const handleMoveUp = (taskId: string) => {
    const idx = tasks.findIndex((t) => t.id === taskId);
    if (idx > 0) {
      const newTasks = [...tasks];
      [newTasks[idx - 1], newTasks[idx]] = [newTasks[idx], newTasks[idx - 1]];
      const orderedIds = newTasks.map((t) => t.id);
      useTaskStore.getState().reorderTasks(date, orderedIds);
    }
  };

  const handleMoveDown = (taskId: string) => {
    const idx = tasks.findIndex((t) => t.id === taskId);
    if (idx < tasks.length - 1) {
      const newTasks = [...tasks];
      [newTasks[idx], newTasks[idx + 1]] = [newTasks[idx + 1], newTasks[idx]];
      const orderedIds = newTasks.map((t) => t.id);
      useTaskStore.getState().reorderTasks(date, orderedIds);
    }
  };

  return (
    <div
      className="flex min-w-[152px] flex-1 flex-col"
      onDragOver={(e) => { e.preventDefault(); }}
      onDrop={(e) => {
        e.preventDefault();
        try {
          const raw = e.dataTransfer.getData('text/plain');
          if (!raw) return;
          const data = JSON.parse(raw);
          if (data.type === 'template') {
            const t = data.template;
            addTask({
              templateId: t.id, date, name: t.name,
              iconType: t.iconType, iconValue: t.iconValue,
              color: t.color, duration: t.defaultDuration,
              status: t.defaultStatus,
              personId: activeMemberId || undefined,
            });
          }
        } catch (err) { console.error('drop error', err); }
      }}
    >
      {/* 柱头 */}
      <div
        className={clsx(
          'relative flex flex-col items-center gap-0.5 rounded-t-xl border border-b-0 px-2 py-2.5',
          today ? 'ring-1 ring-inset' : ''
        )}
        style={{
          minHeight: '60px',
          background: today ? 'var(--color-accent-muted)' : 'var(--color-surface-secondary)',
          borderColor: today ? 'var(--color-accent)' : 'var(--color-border)',
          ringColor: today ? 'var(--color-accent)' : undefined,
        }}
      >
        <span
          className={clsx('text-[10px] font-medium', today && 'font-semibold')}
          style={{ color: today ? 'var(--color-accent)' : 'var(--color-text-muted)' }}
        >
          {display.weekday}
        </span>
        <span
          className={clsx('text-xs font-semibold', today && 'font-bold')}
          style={{ color: 'var(--color-text-primary)' }}
        >
          {display.date}
        </span>
        {today && (
          <span
            className="absolute -bottom-1 left-1/2 -translate-x-1/2 rounded-full px-1.5 py-0.5 text-[8px] font-semibold"
            style={{ background: 'var(--color-accent)', color: '#fff' }}
          >
            今天
          </span>
        )}
      </div>

      {/* 容量柱体 */}
      <div
        ref={setNodeRef}
        className={clsx(
          'relative flex flex-col rounded-b-xl border border-t-0 transition-colors duration-200',
          isOver && 'border-[var(--color-accent)]'
        )}
        style={{
          background: 'var(--color-column-bg)',
          borderColor: isOver ? 'var(--color-accent)' : 'var(--color-border)',
          minHeight: '280px',
        }}
      >
        {/* 时间节点虚线 — 相对于第一个时间节点 */}
        <div className="pointer-events-none absolute inset-x-0 top-0 z-20">
          {(() => {
            const firstNode = schedule.timeNodes[0] || '09:00';
            const [fH, fM] = firstNode.split(':').map(Number);
            const baseMinutes = fH * 60 + fM;

            return schedule.timeNodes.map((node) => {
              const [h, m] = node.split(':').map(Number);
              const minutesFromBase = (h * 60 + m) - baseMinutes;
              const topPx = durationToPx(Math.max(0, minutesFromBase), settings.pxPerHour);
            return (
              <div
                key={node}
                className="absolute left-0 right-0 flex items-center gap-1 px-2"
                style={{ top: `${topPx}px` }}
              >
                <span
                  className="text-[8px] font-medium leading-none"
                  style={{ color: 'var(--color-text-muted)' }}
                >
                  {node}
                </span>
                <div
                  className="flex-1 border-t border-dashed"
                  style={{ borderColor: 'var(--color-border)' }}
                />
              </div>
            );
            });
          })()}
        </div>

        {/* 任务卡片区域 */}
        <div className="relative z-10 flex flex-col">
          {tasks.map((task, idx) => (
            <DroppableTaskWrapper
              key={task.id}
              task={task}
              idx={idx}
              tasks={tasks}
              onMoveUp={handleMoveUp}
              onMoveDown={handleMoveDown}
            />
          ))}

          {/* 空状态 */}
          {tasks.length === 0 && !isOver && (
            <div
              className="flex items-center justify-center py-12"
            >
              <p className="text-[10px]" style={{ color: 'var(--color-text-muted)' }}>
                拖拽模板至此
              </p>
            </div>
          )}

          {/* 拖入高亮 */}
          {isOver && (
            <div
              className="pointer-events-none absolute inset-0 rounded-b-xl border-2 border-dashed"
              style={{
                borderColor: 'var(--color-accent)',
                background: 'var(--color-accent-muted)',
                opacity: 0.3,
              }}
            />
          )}
        </div>

        {/* 超容量区域 */}
        {overflowHeight > 0 && (
          <div
            className="relative z-10 flex items-center justify-center border-t border-dashed mb-1 mx-1"
            style={{
              borderColor: 'var(--color-danger)',
              height: `${Math.min(overflowHeight, 60)}px`,
              background: 'var(--color-danger-muted)',
              borderRadius: '0 0 0.5rem 0.5rem',
            }}
          >
            <span className="text-[9px] font-medium" style={{ color: 'var(--color-danger)' }}>
              +{formatDurationShort(overflowHeight > 60 ? totalUsed - schedule.capacity : remaining * -1)}
            </span>
          </div>
        )}
      </div>

      {/* 柱底：容量信息 */}
      <div
        className="mt-1.5 flex items-center justify-between rounded-lg border px-3 py-1.5"
        style={{
          background: 'var(--color-surface-secondary)',
          borderColor: 'var(--color-border-subtle)',
        }}
      >
        <span className="text-[10px] font-medium" style={{ color: 'var(--color-text-secondary)' }}>
          {formatDurationShort(schedule.capacity)}
        </span>
        <span className={clsx('text-[10px] font-semibold', getUsageColor(usagePercent))}>
          {totalUsed > 0 ? formatDurationShort(totalUsed) : '空闲'}
        </span>
        {remaining > 0 && totalUsed > 0 && (
          <span className="text-[10px]" style={{ color: 'var(--color-text-muted)' }}>
            余{formatDurationShort(remaining)}
          </span>
        )}
      </div>
    </div>
  );
}

/* ===== 主周视图 ===== */
export function WeekView() {
  const [weekOffset, setWeekOffset] = useState(0);

  const baseDate = useMemo(() => {
    const d = new Date();
    d.setDate(d.getDate() + weekOffset * 7);
    return d;
  }, [weekOffset]);

  const weekDates = useMemo(() => getWeekDates(baseDate), [baseDate]);
  const weekLabel = useMemo(() => {
    const s = weekDates[0].slice(5); // MM-DD
    const e = weekDates[6].slice(5);
    const label = s + ' ~ ' + e;
    if (weekOffset === 0) return '本周  ' + label;
    if (weekOffset === -1) return '上周  ' + label;
    if (weekOffset === 1) return '下周  ' + label;
    return label;
  }, [weekDates, weekOffset]);
  const { addTask, updateTask } = useTaskStore();
  const { activeMemberId } = useTeamStore();
  const [panelOpen, setPanelOpen] = useState(true);
  const [activeDragTemplate, setActiveDragTemplate] = useState<Template | null>(null);
  const [activeDragTask, setActiveDragTask] = useState<Task | null>(null);

  // 拖拽传感器（支持鼠标和触控）
  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 5 } }),
    useSensor(TouchSensor, { activationConstraint: { delay: 200, tolerance: 5 } })
  );

  // 处理拖拽
  const handleDragStart = useCallback((event: any) => {
    const { active } = event;
    const data = active.data.current;
    if (data?.type === 'template') {
      setActiveDragTemplate(data.template);
    } else if (data?.type === 'task') {
      setActiveDragTask(data.task);
    }
  }, []);

  const handleDragEnd = useCallback((event: any) => {
    const { active, over } = event;
    setActiveDragTemplate(null);
    setActiveDragTask(null);

    if (!over) return;
    const dropData = over.data.current;
    const activeData = active.data.current;

    // 模板拖到任意有效目标 → 创建任务
    if (activeData?.type === 'template') {
      const template = activeData.template as Template;
      let targetDate: string;
      let targetPersonId: string | undefined = activeMemberId || undefined;

      if (dropData?.type === 'column') {
        targetDate = dropData.date;
        targetPersonId = dropData.personId || activeMemberId || undefined;
      } else if (dropData?.type === 'task') {
        const targetTask = dropData.task as Task;
        targetDate = targetTask.date;
        targetPersonId = targetTask.personId || activeMemberId || undefined;
      } else {
        return;
      }

      addTask({
        templateId: template.id,
        date: targetDate,
        name: template.name,
        iconType: template.iconType,
        iconValue: template.iconValue,
        color: template.color,
        duration: template.defaultDuration,
        status: template.defaultStatus,
        personId: targetPersonId,
      });
      return;
    }

    // 任务拖到另一个柱子 → 移动任务（吸附顶部）
    if (activeData?.type === 'task' && dropData?.type === 'column') {
      const task = activeData.task as Task;
      const targetDate = dropData.date;

      if (task.date !== targetDate) {
        updateTask(task.id, { date: targetDate }); // 移动时吸附底部
      }
      return;
    }

    // 任务拖到同列另一个任务上 → 插入到目标位置
    if (activeData?.type === 'task' && dropData?.type === 'task') {
      const draggedTask = activeData.task as Task;
      const targetTask = dropData.task as Task;

      if (draggedTask.id === targetTask.id) return;

      if (draggedTask.date === targetTask.date) {
        // 同列内排序
        const store = useTaskStore.getState();
        const dateTasks = store.tasks
          .filter((t) => t.date === draggedTask.date)
          .sort((a, b) => a.order - b.order);

        // 找到拖入位置（目标 task 的 index）
        const targetIdx = dateTasks.findIndex((t) => t.id === targetTask.id);
        if (targetIdx === -1) return;

        // 把被拖 task 插入到目标之前
        const reordered = dateTasks.filter((t) => t.id !== draggedTask.id);
        reordered.splice(targetIdx, 0, draggedTask);

        // 更新所有 order
        reordered.forEach((t, i) => {
          if (t.order !== i) store.updateTask(t.id, { order: i });
        });
      }
      return;
    }
  }, [addTask, updateTask, activeMemberId]);

  return (
    <div className="flex h-full flex-col overflow-hidden">
      {/* 顶部工具栏 */}
      <div
        className="flex shrink-0 items-center justify-between border-b px-4 py-2.5"
        style={{ borderColor: 'var(--color-border-subtle)' }}
      >
        <div className="flex items-center gap-2">
          {!panelOpen && (
            <button
              onClick={() => setPanelOpen(true)}
              className="rounded-md p-1.5 hover:bg-[var(--color-surface-secondary)] transition-colors"
              title="展开模板面板"
            >
              <PanelLeft size={16} style={{ color: 'var(--color-text-secondary)' }} />
            </button>
          )}
          <h1 className="text-sm font-semibold tracking-tight" style={{ color: 'var(--color-text-primary)' }}>
            周视图
          </h1>
        </div>
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setWeekOffset((o) => o - 1)}
            className="rounded-md p-1 transition-colors hover:bg-[var(--color-surface-secondary)]"
            title="上一周"
          >
            <ChevronLeft size={16} style={{ color: 'var(--color-text-secondary)' }} />
          </button>
          <span
            className="min-w-[160px] text-center text-xs font-medium"
            style={{ color: weekOffset === 0 ? 'var(--color-accent)' : 'var(--color-text-primary)' }}
          >
            {weekLabel}
          </span>
          <button
            onClick={() => setWeekOffset((o) => o + 1)}
            className="rounded-md p-1 transition-colors hover:bg-[var(--color-surface-secondary)]"
            title="下一周"
          >
            <ChevronRight
              size={16}
              style={{ color: 'var(--color-text-secondary)' }}
            />
          </button>
          {weekOffset !== 0 && (
            <button
              onClick={() => setWeekOffset(0)}
              className="rounded px-2 py-0.5 text-[10px] font-medium transition-colors hover:bg-[var(--color-accent-muted)]"
              style={{ color: 'var(--color-accent)' }}
            >
              回到本周
            </button>
          )}
        </div>
      </div>

      {/* 主体：模板面板 + 容量柱（全部在 DndContext 内） */}
      <DndContext
        sensors={sensors}
        collisionDetection={closestCorners}
        modifiers={[restrictToWindowEdges]}
        onDragStart={handleDragStart}
        onDragEnd={handleDragEnd}
      >
        <div className="flex flex-1 overflow-hidden">
          <TemplatePanel open={panelOpen} onToggle={() => setPanelOpen(false)} weekStart={weekDates[0]} />

          <div className="flex flex-1 gap-2 overflow-x-auto p-3">
            {weekDates.map((date) =>
              activeMemberId ? (
                <CapacityColumn key={date} date={date} />
              ) : (
                <MultiMemberColumn key={date} date={date} />
              )
            )}
          </div>
        </div>

        {/* 拖拽预览浮层 */}
        <DragOverlay dropAnimation={null}>
            {activeDragTemplate && (
              <div
                className="flex items-center gap-2 rounded-lg border p-2.5 shadow-lg"
                style={{
                  background: 'var(--color-surface)',
                  borderColor: activeDragTemplate.color,
                  borderLeftWidth: '3px',
                }}
              >
                <div
                  className="flex h-7 w-7 items-center justify-center rounded-md"
                  style={{ background: activeDragTemplate.color + '1a', color: activeDragTemplate.color }}
                >
                  <TemplateIcon name={activeDragTemplate.iconValue} size={13} />
                </div>
                <div>
                  <p className="text-[11px] font-medium" style={{ color: 'var(--color-text-primary)' }}>
                    {activeDragTemplate.name}
                  </p>
                  <p className="text-[9px]" style={{ color: 'var(--color-text-muted)' }}>
                    {formatDurationShort(activeDragTemplate.defaultDuration)}
                  </p>
                </div>
              </div>
            )}
            {activeDragTask && (
              <div
                className="rounded-lg border p-2.5 shadow-lg"
                style={{
                  background: 'var(--color-surface)',
                  borderColor: activeDragTask.color,
                  borderLeftWidth: '3px',
                  borderLeftColor: activeDragTask.color,
                }}
              >
                <div className="flex items-center gap-1.5">
                  <TemplateIcon name={activeDragTask.iconValue} size={12} />
                  <span className="text-[11px] font-medium" style={{ color: 'var(--color-text-primary)' }}>
                    {activeDragTask.name}
                  </span>
                </div>
                <p className="mt-1 text-[9px]" style={{ color: 'var(--color-text-muted)' }}>
                  {formatDurationShort(activeDragTask.duration)}
                </p>
              </div>
            )}
          </DragOverlay>
        </DndContext>
    </div>
  );
}
