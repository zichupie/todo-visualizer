/* ===== 模板分类 ===== */
export interface TemplateCategory {
  id: string;
  name: string;
  order: number;
  createdAt: string;
}

/* ===== 工作模板 ===== */
export interface Template {
  id: string;
  name: string;
  iconType: 'lucide' | 'custom';
  iconValue: string;
  iconFileName?: string;
  color: string;
  defaultDuration: number; // 分钟
  categoryId: string | null;
  defaultStatus: TaskStatus;
  order: number;
  createdAt: string;
  updatedAt: string;
}

/* ===== 任务状态 ===== */
export type TaskStatus = 'todo' | 'in-progress' | 'review' | 'done';

/* ===== 任务实例 ===== */
export interface Task {
  id: string;
  templateId: string | null;
  date: string; // YYYY-MM-DD
  name: string;
  iconType: 'lucide' | 'custom';
  iconValue: string;
  color: string;
  duration: number; // 分钟
  status: TaskStatus;
  note: string;
  locked: boolean;
  order: number; // 仅内存，不持久化
  ownerId: string; // 预留
  personId?: string; // 预留
  gestureZone?: 'drag' | 'resize' | null; // 预留
  createdAt: string;
  updatedAt: string;
}

/* ===== 每日排期 ===== */
export interface Schedule {
  date: string;
  capacity: number; // 分钟
  isOverridden: boolean;
  timeNodes: string[]; // ['09:00', '12:00', '14:00', '18:00']
}

/* ===== 应用设置 ===== */
export type ThemeMode = 'light' | 'dark' | 'system';

export interface AppSettings {
  id: 'default';
  defaultCapacity: number; // 分钟，默认 480
  pxPerHour: number; // 默认 50，最小 10
  theme: ThemeMode;
  lastBackupAt: string | null;
  dataDir: string;
  backupDir: string; // 备份保存路径（用户指定）
  autoBackup: boolean; // 是否启用自动备份
}

/* ===== 历史操作记录 ===== */
export type HistoryEventType =
  | 'create_task'
  | 'delete_task'
  | 'update_task'
  | 'move_task'
  | 'merge_task'
  | 'update_template'
  | 'copy_schedule';

export interface HistoryEvent {
  id: string;
  type: HistoryEventType;
  payload: string; // JSON 序列化
  description: string;
  createdAt: string;
}

/* ===== 状态标签映射 ===== */
export const STATUS_LABELS: Record<TaskStatus, string> = {
  'todo': '待办',
  'in-progress': '进行中',
  'review': '待审核',
  'done': '已完成',
};

export const STATUS_COLORS: Record<TaskStatus, string> = {
  'todo': '#94a3b8',
  'in-progress': '#6366f1',
  'review': '#f59e0b',
  'done': '#22c55e',
};

/* ===== 预设颜色池 ===== */
export const PRESET_COLORS = [
  '#6366f1', '#8b5cf6', '#a855f7',
  '#ec4899', '#f43f5e', '#ef4444',
  '#f97316', '#f59e0b', '#eab308',
  '#22c55e', '#10b981', '#14b8a6',
  '#06b6d4', '#3b82f6', '#2563eb',
  '#64748b', '#475569', '#334155',
];

/* ===== 默认时间节点 ===== */
export const DEFAULT_TIME_NODES = ['09:30', '12:00', '14:00', '17:30'];

/* ===== 默认设置 ===== */
export const DEFAULT_SETTINGS: AppSettings = {
  id: 'default',
  defaultCapacity: 480, // 8h（09:30-17:30）
  pxPerHour: 50,
  theme: 'system',
  lastBackupAt: null,
  dataDir: '',
  backupDir: '',
  autoBackup: false,
};
