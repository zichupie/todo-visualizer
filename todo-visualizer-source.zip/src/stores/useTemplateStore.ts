import { create } from 'zustand';
import { v4 as uuidv4 } from 'uuid';
import type { Template, TemplateCategory, TaskStatus } from '@/types';
import { PRESET_COLORS } from '@/types';
import { loadFromStorage, saveToStorage } from '@/services/dataDir';

const STORAGE_KEY = 'wce_templates';
const CATEGORY_KEY = 'wce_template_categories';

interface TemplateState {
  templates: Template[];
  categories: TemplateCategory[];
  selectedCategoryId: string | null;

  // 分类操作
  addCategory: (name: string) => TemplateCategory;
  renameCategory: (id: string, name: string) => void;
  deleteCategory: (id: string) => void;
  setSelectedCategory: (id: string | null) => void;

  // 模板操作
  addTemplate: (data: Partial<Template>) => Template;
  updateTemplate: (id: string, data: Partial<Template>) => void;
  deleteTemplate: (id: string) => void;
  reorderTemplate: (id: string, newOrder: number) => void;
  moveTemplateToCategory: (id: string, categoryId: string | null) => void;

  // 数据加载
  load: () => void;
  save: () => void;
}

export const useTemplateStore = create<TemplateState>((set, get) => ({
  templates: [],
  categories: [],
  selectedCategoryId: null,

  addCategory: (name) => {
    const category: TemplateCategory = {
      id: uuidv4(),
      name,
      order: get().categories.length,
      createdAt: new Date().toISOString(),
    };
    set((state) => {
      const newCategories = [...state.categories, category];
      saveToStorage(CATEGORY_KEY, newCategories);
      return { categories: newCategories };
    });
    return category;
  },

  renameCategory: (id, name) => {
    set((state) => {
      const newCategories = state.categories.map((c) =>
        c.id === id ? { ...c, name } : c
      );
      saveToStorage(CATEGORY_KEY, newCategories);
      return { categories: newCategories };
    });
  },

  deleteCategory: (id) => {
    set((state) => {
      const newCategories = state.categories.filter((c) => c.id !== id);
      saveToStorage(CATEGORY_KEY, newCategories);
      // 将被删除分类下的模板移到未分类
      const newTemplates = state.templates.map((t) =>
        t.categoryId === id ? { ...t, categoryId: null } : t
      );
      saveToStorage(STORAGE_KEY, newTemplates);
      return {
        categories: newCategories,
        templates: newTemplates,
        selectedCategoryId: state.selectedCategoryId === id ? null : state.selectedCategoryId,
      };
    });
  },

  setSelectedCategory: (id) => {
    set({ selectedCategoryId: id });
  },

  addTemplate: (data) => {
    const state = get();
    const usedColors = new Set(state.templates.map((t) => t.color));
    const availableColor = PRESET_COLORS.find((c) => !usedColors.has(c)) || PRESET_COLORS[0];

    const template: Template = {
      id: uuidv4(),
      name: data.name || '未命名模板',
      iconType: data.iconType || 'lucide',
      iconValue: data.iconValue || 'clipboard-list',
      color: data.color || availableColor,
      defaultDuration: data.defaultDuration || 60,
      categoryId: data.categoryId || null,
      defaultStatus: data.defaultStatus || 'todo',
      order: state.templates.length,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    set((s) => {
      const newTemplates = [...s.templates, template];
      saveToStorage(STORAGE_KEY, newTemplates);
      return { templates: newTemplates };
    });
    return template;
  },

  updateTemplate: (id, data) => {
    set((state) => {
      const newTemplates = state.templates.map((t) =>
        t.id === id ? { ...t, ...data, updatedAt: new Date().toISOString() } : t
      );
      saveToStorage(STORAGE_KEY, newTemplates);
      return { templates: newTemplates };
    });
  },

  deleteTemplate: (id) => {
    set((state) => {
      const newTemplates = state.templates.filter((t) => t.id !== id);
      saveToStorage(STORAGE_KEY, newTemplates);
      return { templates: newTemplates };
    });
  },

  reorderTemplate: (id, newOrder) => {
    set((state) => {
      const newTemplates = state.templates.map((t) =>
        t.id === id ? { ...t, order: newOrder } : t
      );
      saveToStorage(STORAGE_KEY, newTemplates);
      return { templates: newTemplates };
    });
  },

  moveTemplateToCategory: (id, categoryId) => {
    set((state) => {
      const newTemplates = state.templates.map((t) =>
        t.id === id ? { ...t, categoryId } : t
      );
      saveToStorage(STORAGE_KEY, newTemplates);
      return { templates: newTemplates };
    });
  },

  load: () => {
    const templates = loadFromStorage<Template[]>(STORAGE_KEY, []);
    const categories = loadFromStorage<TemplateCategory[]>(CATEGORY_KEY, []);
    set({ templates, categories });
  },

  save: () => {
    saveToStorage(STORAGE_KEY, get().templates);
    saveToStorage(CATEGORY_KEY, get().categories);
  },
}));
