import { create } from 'zustand';
import type { AppSettings, ThemeMode } from '@/types';
import { DEFAULT_SETTINGS } from '@/types';
import { loadSettings, saveSettings } from '@/services/dataDir';

interface SettingState {
  settings: AppSettings;
  initialized: boolean;
  activePage: 'week' | 'team' | 'templates' | 'settings';

  // 设置更新
  updateSettings: (data: Partial<AppSettings>) => void;

  // 快捷方法
  setTheme: (theme: ThemeMode) => void;
  setDefaultCapacity: (capacity: number) => void;
  setPxPerHour: (px: number) => void;

  // 页面导航
  setActivePage: (page: 'week' | 'team' | 'templates' | 'settings') => void;

  // 初始化
  init: () => void;
}

export const useSettingStore = create<SettingState>((set, get) => ({
  settings: DEFAULT_SETTINGS,
  initialized: false,
  activePage: 'week',

  updateSettings: (data) => {
    set((state) => {
      const newSettings = { ...state.settings, ...data };
      saveSettings(newSettings);
      return { settings: newSettings };
    });
  },

  setTheme: (theme) => {
    get().updateSettings({ theme });
    applyTheme(theme);
  },

  setDefaultCapacity: (capacity) => {
    get().updateSettings({ defaultCapacity: capacity });
  },

  setPxPerHour: (px) => {
    const clamped = Math.max(10, px);
    get().updateSettings({ pxPerHour: clamped });
  },

  setActivePage: (page) => {
    set({ activePage: page });
  },

  init: () => {
    const settings = loadSettings();
    set({ settings, initialized: true });
    applyTheme(settings.theme);
  },
}));

/**
 * 应用主题到 DOM
 */
function applyTheme(theme: ThemeMode): void {
  const root = document.documentElement;

  if (theme === 'system') {
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    root.classList.toggle('dark', prefersDark);
  } else {
    root.classList.toggle('dark', theme === 'dark');
  }
}

/**
 * 监听系统主题变化
 */
if (typeof window !== 'undefined') {
  window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
    const state = useSettingStore.getState();
    if (state.settings.theme === 'system') {
      applyTheme('system');
    }
  });
}
