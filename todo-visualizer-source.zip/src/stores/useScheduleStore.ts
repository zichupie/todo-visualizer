import { create } from 'zustand';
import type { Schedule } from '@/types';
import { DEFAULT_TIME_NODES, DEFAULT_SETTINGS } from '@/types';
import { loadFromStorage, saveToStorage } from '@/services/dataDir';

const STORAGE_KEY = 'wce_schedules';

interface ScheduleState {
  schedules: Schedule[];

  // 获取某天的排期（不存在则创建默认）
  getOrCreateSchedule: (date: string) => Schedule;

  // 设置某天容量
  setCapacity: (date: string, capacity: number) => void;

  // 重置某天容量为默认值
  resetCapacity: (date: string, defaultCapacity: number) => void;

  // 批量设置容量（一键统一）
  batchSetCapacity: (dates: string[], capacity: number) => void;

  // 设置某天的时间节点
  setTimeNodes: (date: string, timeNodes: string[]) => void;

  // 数据
  load: () => void;
  save: () => void;
}

export const useScheduleStore = create<ScheduleState>((set, get) => ({
  schedules: [],

  getOrCreateSchedule: (date) => {
    const state = get();
    let schedule = state.schedules.find((s) => s.date === date);

    if (!schedule) {
      schedule = {
        date,
        capacity: DEFAULT_SETTINGS.defaultCapacity,
        isOverridden: false,
        timeNodes: [...DEFAULT_TIME_NODES],
      };
      set((s) => {
        const newSchedules = [...s.schedules, schedule!];
        saveToStorage(STORAGE_KEY, newSchedules);
        return { schedules: newSchedules };
      });
    }

    return schedule;
  },

  setCapacity: (date, capacity) => {
    set((state) => {
      const existing = state.schedules.find((s) => s.date === date);
      let newSchedules: Schedule[];

      if (existing) {
        newSchedules = state.schedules.map((s) =>
          s.date === date ? { ...s, capacity, isOverridden: true } : s
        );
      } else {
        const schedule: Schedule = {
          date,
          capacity,
          isOverridden: true,
          timeNodes: [...DEFAULT_TIME_NODES],
        };
        newSchedules = [...state.schedules, schedule];
      }

      saveToStorage(STORAGE_KEY, newSchedules);
      return { schedules: newSchedules };
    });
  },

  resetCapacity: (date, defaultCapacity) => {
    set((state) => {
      const newSchedules = state.schedules.map((s) =>
        s.date === date
          ? { ...s, capacity: defaultCapacity, isOverridden: false }
          : s
      );
      saveToStorage(STORAGE_KEY, newSchedules);
      return { schedules: newSchedules };
    });
  },

  batchSetCapacity: (dates, capacity) => {
    set((state) => {
      const dateSet = new Set(dates);
      const newSchedules = state.schedules.map((s) =>
        dateSet.has(s.date) ? { ...s, capacity, isOverridden: true } : s
      );

      // 为不存在的日期创建排期
      for (const date of dates) {
        if (!newSchedules.find((s) => s.date === date)) {
          newSchedules.push({
            date,
            capacity,
            isOverridden: true,
            timeNodes: [...DEFAULT_TIME_NODES],
          });
        }
      }

      saveToStorage(STORAGE_KEY, newSchedules);
      return { schedules: newSchedules };
    });
  },

  setTimeNodes: (date, timeNodes) => {
    set((state) => {
      const existing = state.schedules.find((s) => s.date === date);
      let newSchedules: Schedule[];

      if (existing) {
        newSchedules = state.schedules.map((s) =>
          s.date === date ? { ...s, timeNodes } : s
        );
      } else {
        newSchedules = [
          ...state.schedules,
          {
            date,
            capacity: DEFAULT_SETTINGS.defaultCapacity,
            isOverridden: false,
            timeNodes,
          },
        ];
      }

      saveToStorage(STORAGE_KEY, newSchedules);
      return { schedules: newSchedules };
    });
  },

  load: () => {
    const schedules = loadFromStorage<Schedule[]>(STORAGE_KEY, []);
    set({ schedules });
  },

  save: () => {
    saveToStorage(STORAGE_KEY, get().schedules);
  },
}));
