import { create } from 'zustand';
import { loadFromStorage, saveToStorage } from '@/services/dataDir';

const STORAGE_KEY = 'wce_team';

export interface TeamMember {
  id: string;
  name: string;
  color: string;
}

export const DEFAULT_MEMBERS: TeamMember[] = [
  { id: 'person-1', name: '橙子', color: '#f97316' },
  { id: 'person-2', name: '晶晶', color: '#06b6d4' },
  { id: 'person-3', name: '陈阳', color: '#10b981' },
];

interface TeamState {
  members: TeamMember[];
  activeMemberId: string | null; // null = 查看全部

  setActiveMember: (id: string | null) => void;
  load: () => void;
  save: () => void;
}

export const useTeamStore = create<TeamState>((set, get) => ({
  members: DEFAULT_MEMBERS,
  activeMemberId: null,

  setActiveMember: (id) => {
    set({ activeMemberId: id });
  },

  load: () => {
    const saved = loadFromStorage<{ members?: TeamMember[] }>(STORAGE_KEY, {});
    if (saved.members && saved.members.length > 0) {
      set({ members: saved.members });
    } else {
      // 首次使用，写入默认成员
      saveToStorage(STORAGE_KEY, { members: DEFAULT_MEMBERS });
    }
  },

  save: () => {
    saveToStorage(STORAGE_KEY, { members: get().members });
  },
}));
