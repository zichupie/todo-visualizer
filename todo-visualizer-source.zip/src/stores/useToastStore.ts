import { create } from 'zustand';

interface ToastItem {
  id: string;
  message: string;
  type: 'success' | 'error' | 'info';
}

interface ToastState {
  toasts: ToastItem[];
  show: (message: string, type?: 'success' | 'error' | 'info') => void;
  dismiss: (id: string) => void;
}

let _id = 0;
const nextId = () => String(++_id);

export const useToastStore = create<ToastState>((set) => ({
  toasts: [],
  show: (message, type = 'success') => {
    const id = nextId();
    set((s) => ({ toasts: [...s.toasts, { id, message, type }] }));
    // 1.5 秒后自动消除
    setTimeout(() => {
      set((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) }));
    }, 1800);
  },
  dismiss: (id) => {
    set((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) }));
  },
}));
