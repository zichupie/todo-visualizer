import { create } from 'zustand';
import { v4 as uuidv4 } from 'uuid';
import type { Task, TaskStatus } from '@/types';
import { loadFromStorage, saveToStorage } from '@/services/dataDir';
import { historyManager } from '@/services/history';

const STORAGE_KEY = 'wce_tasks';

interface TaskState {
  tasks: Task[];
  editingTaskId: string | null;
  drawerOpen: boolean;

  // CRUD
  addTask: (data: Partial<Task> & { date: string }) => Task;
  updateTask: (id: string, data: Partial<Task>) => void;
  deleteTask: (id: string) => void;

  // 批量操作
  copyTasksToDate: (taskIds: string[], targetDate: string) => Task[];

  // 排序（仅内存）
  reorderTasks: (date: string, orderedIds: string[]) => void;

  // 编辑面板
  openDrawer: (taskId: string) => void;
  closeDrawer: () => void;

  // 查询
  getTasksByDate: (date: string) => Task[];
  getTotalDurationByDate: (date: string) => number;

  // 数据
  load: () => void;
  save: () => void;
}

export const useTaskStore = create<TaskState>((set, get) => ({
  tasks: [],
  editingTaskId: null,
  drawerOpen: false,

  addTask: (data) => {
    const task: Task = {
      id: uuidv4(),
      templateId: data.templateId || null,
      date: data.date,
      name: data.name || '未命名任务',
      iconType: data.iconType || 'lucide',
      iconValue: data.iconValue || 'clipboard-list',
      color: data.color || '#94a3b8',
      duration: data.duration ?? 60,
      status: data.status || 'todo',
      note: data.note || '',
      locked: data.locked || false,
      order: data.order ?? get().tasks.filter((t) => t.date === data.date).length, // 默认底部
      ownerId: data.ownerId || 'default',
      personId: data.personId,
      gestureZone: null,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    set((state) => {
      const newTasks = [...state.tasks, task];
      saveToStorage(STORAGE_KEY, newTasks);
      return { tasks: newTasks };
    });

    historyManager.record('create_task', { taskId: task.id }, `创建任务「${task.name}」`);
    return task;
  },

  updateTask: (id, data) => {
    set((state) => {
      const newTasks = state.tasks.map((t) =>
        t.id === id ? { ...t, ...data, updatedAt: new Date().toISOString() } : t
      );
      saveToStorage(STORAGE_KEY, newTasks);
      return { tasks: newTasks };
    });

    const task = get().tasks.find((t) => t.id === id);
    if (task) {
      historyManager.record('update_task', { taskId: id, changes: data }, `修改任务「${task.name}」`);
    }
  },

  deleteTask: (id) => {
    const task = get().tasks.find((t) => t.id === id);
    set((state) => {
      const newTasks = state.tasks.filter((t) => t.id !== id);
      saveToStorage(STORAGE_KEY, newTasks);
      return { tasks: newTasks, drawerOpen: false, editingTaskId: null };
    });

    if (task) {
      historyManager.record('delete_task', { taskId: id, task }, `删除任务「${task.name}」`);
    }
  },

  copyTasksToDate: (taskIds, targetDate) => {
    const state = get();
    const sourceTasks = state.tasks.filter((t) => taskIds.includes(t.id));
    const newTasks: Task[] = sourceTasks.map((t, idx) => ({
      ...t,
      id: uuidv4(),
      date: targetDate,
      order: state.tasks.filter((x) => x.date === targetDate).length + idx,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      templateId: t.templateId,
    }));

    set((s) => {
      const allTasks = [...s.tasks, ...newTasks];
      saveToStorage(STORAGE_KEY, allTasks);
      return { tasks: allTasks };
    });

    historyManager.record(
      'copy_schedule',
      { taskIds: newTasks.map((t) => t.id), targetDate },
      `复制 ${newTasks.length} 个任务到 ${targetDate}`
    );

    return newTasks;
  },

  reorderTasks: (date, orderedIds) => {
    set((state) => {
      const dateTasks = state.tasks.filter((t) => t.date === date);
      const otherTasks = state.tasks.filter((t) => t.date !== date);

      const reordered = orderedIds
        .map((id, index) => {
          const task = dateTasks.find((t) => t.id === id);
          return task ? { ...task, order: index } : null;
        })
        .filter(Boolean) as Task[];

      // 保留不在排序列表中的任务
      const remainingIds = new Set(orderedIds);
      const remaining = dateTasks.filter((t) => !remainingIds.has(t.id));

      const allTasks = [...otherTasks, ...reordered, ...remaining];
      return { tasks: allTasks };
    });
  },

  openDrawer: (taskId) => {
    set({ editingTaskId: taskId, drawerOpen: true });
  },

  closeDrawer: () => {
    set({ editingTaskId: null, drawerOpen: false });
  },

  getTasksByDate: (date) => {
    return get()
      .tasks.filter((t) => t.date === date)
      .sort((a, b) => a.order - b.order);
  },

  getTotalDurationByDate: (date) => {
    return get()
      .tasks.filter((t) => t.date === date)
      .reduce((sum, t) => sum + t.duration, 0);
  },

  load: () => {
    const tasks = loadFromStorage<Task[]>(STORAGE_KEY, []);
    set({ tasks });
  },

  save: () => {
    saveToStorage(STORAGE_KEY, get().tasks);
  },
}));
