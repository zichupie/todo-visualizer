import { create } from 'zustand';
import { v4 as uuidv4 } from 'uuid';
import { loadFromStorage, saveToStorage } from '@/services/dataDir';
import { getWeekDates } from '@/utils/date';

const STORAGE_KEY = 'wce_quickTasks';

export interface QuickTask {
  id: string;
  name: string;
  iconValue: string;
  color: string;
  duration: number; // 分钟
  weekStart: string; // 所属周的周一日期 YYYY-MM-DD
  createdAt: string;
}

interface QuickTaskState {
  tasks: QuickTask[];

  /** 获取当前周的快速任务 */
  getCurrentWeekTasks: () => QuickTask[];

  /** 获取指定周的快速任务 */
  getTasksByWeek: (weekStart: string) => QuickTask[];

  /** 添加快速任务 */
  addTask: (data: Omit<QuickTask, 'id' | 'weekStart' | 'createdAt'>, weekStart?: string) => QuickTask;

  /** 删除快速任务 */
  deleteTask: (id: string) => void;

  /** 清理旧周数据（保留最近4周） */
  cleanup: () => void;

  /** 加载/保存 */
  load: () => void;
  save: () => void;
}

export const useQuickTaskStore = create<QuickTaskState>((set, get) => ({
  tasks: [],

  getCurrentWeekTasks: () => {
    const weekStart = getWeekDates()[0];
    return get().tasks.filter((t) => t.weekStart === weekStart);
  },

  getTasksByWeek: (weekStart) => {
    return get().tasks.filter((t) => t.weekStart === weekStart);
  },

  addTask: (data, weekStart) => {
    const ws = weekStart || getWeekDates()[0];
    const task: QuickTask = {
      id: uuidv4(),
      name: data.name,
      iconValue: data.iconValue,
      color: data.color,
      duration: data.duration,
      weekStart: ws,
      createdAt: new Date().toISOString(),
    };

    set((state) => {
      const newTasks = [...state.tasks, task];
      saveToStorage(STORAGE_KEY, newTasks);
      return { tasks: newTasks };
    });

    return task;
  },

  deleteTask: (id) => {
    set((state) => {
      const newTasks = state.tasks.filter((t) => t.id !== id);
      saveToStorage(STORAGE_KEY, newTasks);
      return { tasks: newTasks };
    });
  },

  cleanup: () => {
    const weeks = getWeekDates();
    const keepStart = weeks[0]; // 当前周
    set((state) => {
      const newTasks = state.tasks.filter((t) => t.weekStart >= keepStart);
      saveToStorage(STORAGE_KEY, newTasks);
      return { tasks: newTasks };
    });
  },

  load: () => {
    const tasks = loadFromStorage<QuickTask[]>('wce_quickTasks', []);
    set({ tasks });
  },

  save: () => {
    saveToStorage(STORAGE_KEY, get().tasks);
  },
}));
