import { create } from 'zustand';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import type { User, Session } from '@supabase/supabase-js';

interface AuthState {
  /** 当前登录用户 */
  user: User | null;
  /** 当前会话 */
  session: Session | null;
  /** 是否正在加载认证状态 */
  loading: boolean;
  /** 是否已配置 Supabase */
  configured: boolean;
  /** 登录弹窗是否打开 */
  showAuthModal: boolean;

  // Actions
  setShowAuthModal: (show: boolean) => void;
  initialize: () => Promise<void>;
  signIn: (email: string, password: string) => Promise<{ error?: string }>;
  signUp: (email: string, password: string) => Promise<{ error?: string }>;
  signOut: () => Promise<void>;
}

export const useAuthStore = create<AuthState>((set, get) => ({
  user: null,
  session: null,
  loading: true,
  configured: isSupabaseConfigured(),
  showAuthModal: false,

  setShowAuthModal: (show) => set({ showAuthModal: show }),

  initialize: async () => {
    const configured = isSupabaseConfigured();
    if (!configured) {
      set({ loading: false, configured: false });
      return;
    }

    try {
      // 尝试恢复之前的会话
      const { data: { session } } = await supabase.auth.getSession();
      set({
        session,
        user: session?.user ?? null,
        loading: false,
        configured: true,
      });

      // 监听认证状态变化（其他标签页登录/登出）
      supabase.auth.onAuthStateChange((_event, session) => {
        set({
          session,
          user: session?.user ?? null,
        });
      });
    } catch {
      set({ loading: false, configured: true });
    }
  },

  signIn: async (email, password) => {
    if (!get().configured) {
      return { error: 'Supabase 未配置' };
    }

    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      // 友好的错误消息
      const messages: Record<string, string> = {
        'Invalid login credentials': '邮箱或密码错误',
        'Email not confirmed': '请先验证邮箱',
        'Too many requests': '登录太频繁，请稍后再试',
      };
      return { error: messages[error.message] || error.message };
    }

    set({ showAuthModal: false });
    return {};
  },

  signUp: async (email, password) => {
    if (!get().configured) {
      return { error: 'Supabase 未配置' };
    }

    const { error } = await supabase.auth.signUp({
      email,
      password,
    });

    if (error) {
      const messages: Record<string, string> = {
        'User already registered': '该邮箱已注册',
        'Password should be at least 6 characters': '密码至少 6 位',
      };
      return { error: messages[error.message] || error.message };
    }

    return {};
  },

  signOut: async () => {
    await supabase.auth.signOut();
    set({ user: null, session: null });
  },
}));
