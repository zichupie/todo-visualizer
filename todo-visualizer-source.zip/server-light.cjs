/**
 * Todo Visualizer - 内嵌 HTTP 服务器
 * 提供静态文件 + 文件系统数据持久化 API
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');

// ── 查找 exe 所在目录 ──
const EXE_DIR = path.dirname(process.execPath);

// ── dist 目录（pkg 内嵌优先）──
const DIST = (() => {
  const pkgDist = path.join(__dirname, 'dist');
  if (fs.existsSync(pkgDist)) return pkgDist;
  const exeDist = path.join(EXE_DIR, 'dist');
  if (fs.existsSync(exeDist)) return exeDist;
  const cwdDist = path.join(process.cwd(), 'dist');
  if (fs.existsSync(cwdDist)) return cwdDist;
  return null;
})();

if (!DIST) {
  process.stderr.write('\n  ERROR: dist/ folder not found!\n  Press any key to exit...');
  process.stdin.setRawMode(true); process.stdin.resume();
  process.stdin.on('data', () => process.exit(1));
}

// ── 数据目录（项目目录 data/ → exe 同目录 data/ → 新建）──
const DATA_DIR = (() => {
  // 1. 当前工作目录（开发模式 node server-light.cjs）
  const cwdData = path.join(process.cwd(), 'data');
  if (fs.existsSync(cwdData)) return cwdData;
  // 2. exe 同目录（打包模式）
  const exeData = path.join(EXE_DIR, 'data');
  if (fs.existsSync(exeData)) return exeData;
  // 3. 新建在 cwd
  fs.mkdirSync(cwdData, { recursive: true });
  return cwdData;
})();

// ── MIME ──
const MIME = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8', '.json': 'application/json',
  '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon',
  '.webp': 'image/webp',
};

// ── 文件路径安全校验 ──
function safePath(base, ...parts) {
  // 去掉 leading /assets/xxx → assets/xxx
  const cleanParts = parts.map(p => p.replace(/^\//, ''));
  const resolved = path.resolve(base, ...cleanParts);
  if (!resolved.startsWith(base)) return null;
  return resolved;
}

// ── 读取数据 ──
function loadData(key) {
  const fp = path.join(DATA_DIR, key + '.json');
  if (!fs.existsSync(fp)) return null;
  try { return JSON.parse(fs.readFileSync(fp, 'utf-8')); }
  catch { return null; }
}

// ── 保存数据 ──
function saveData(key, data) {
  const fp = path.join(DATA_DIR, key + '.json');
  try {
    fs.writeFileSync(fp, JSON.stringify(data, null, 2), 'utf-8');
    return true;
  } catch { return false; }
}

// ── 解析 JSON body ──
function parseBody(req, cb) {
  let body = '';
  req.on('data', (chunk) => { body += chunk; if (body.length > 5e6) req.destroy(); });
  req.on('end', () => {
    try { cb(JSON.parse(body)); } catch { cb(null); }
  });
}

// ── HTTP Server ──
const server = http.createServer((req, res) => {
  const url = new URL(req.url, 'http://localhost');
  const reqPath = url.pathname;

  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    return res.end();
  }

  // ── API: 加载数据 ──
  if (req.method === 'GET' && reqPath === '/api/data') {
    const key = url.searchParams.get('key');
    if (!key) { res.writeHead(400); return res.end('Missing key'); }
    const data = loadData(key);
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify(data ?? null));
  }

  // ── API: 保存数据 ──
  if (req.method === 'POST' && reqPath === '/api/data') {
    parseBody(req, (body) => {
      if (!body || !body.key) { res.writeHead(400); return res.end('Invalid body'); }
      const ok = saveData(body.key, body.data);
      res.writeHead(ok ? 200 : 500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok }));
    });
    return;
  }

  // ── 静态文件 ──
  const filePath = safePath(DIST, reqPath === '/' ? 'index.html' : reqPath);
  if (!filePath) { res.writeHead(403); return res.end(); }

  try {
    const data = fs.readFileSync(filePath);
    const ext = path.extname(filePath);
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    res.end(data);
  } catch {
    try {
      const fb = fs.readFileSync(path.join(DIST, 'index.html'));
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      res.end(fb);
    } catch { res.writeHead(404); res.end(); }
  }
});

// ── 端口探测启动 ──
let PORT = 5000;
(function tryListen() {
  server.listen(PORT, () => {
    process.stdout.write('\n  Todo Visualizer  http://localhost:' + PORT + '\n  Data: ' + DATA_DIR + '\n  Close window to stop.\n\n');
    exec('start http://localhost:' + PORT, () => {});
  });
  server.on('error', (err) => {
    if (err.code === 'EADDRINUSE' && ++PORT <= 5010) {
      server.close(); tryListen();
    } else {
      process.stdout.write('\n  ERROR: Ports 5000-5010 in use!\n  Press any key...');
      process.stdin.setRawMode(true); process.stdin.resume();
      process.stdin.on('data', () => process.exit(1));
    }
  });
})();
